// riscv64-unknown-linux-gnu-gcc  -march=rv64gcv vmadot-gemm-demo.c -o gemm-vmadot-4x8x4

#include <assert.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

double get_ns(struct timespec t) { return (t.tv_sec * 1000000000 + t.tv_nsec); }

void Gemm_ref(size_t M,
                       size_t N,
                       size_t K,
                       const int8_t* A,
                       const int8_t* B,
                       int32_t* C) {

  for (size_t m = 0; m < M; ++m) {
    for (size_t n = 0; n < N; ++n) {
      int32_t acc = 0;
      for (size_t k = 0; k < K; ++k) {
        int8_t a = A[m * K + k];
        int8_t b = B[k * N + n];
        acc += a * b;
      }
      C[m * N + n] = acc;
    }
  }
}



#define KERNEL16x8x8_I                                    \
  "vle8.v         v8,         (t1)                  \n\t" \
  "addi           t1,         t1,         4*4*8     \n\t" \
  "vle8.v         v9,         (t2)                  \n\t" \
  "addi           t2,         t2,         4*4*8     \n\t" \
  "vle8.v         v10,        (t3)                  \n\t" \
  "addi           t3,         t3,         4*4*8     \n\t" \
  "vle8.v         v11,        (t4)                  \n\t" \
  "addi           t4,         t4,         4*4*8     \n\t" \
                                                          \
  "vle8.v         v0,         (s1)                  \n\t" \
  "addi           s1,         s1,         8*4*8     \n\t" \
  "vle8.v         v1,         (s2)                  \n\t" \
  "addi           s2,         s2,         8*4*8     \n\t" \
  "vle8.v         v2,         (s3)                  \n\t" \
  "addi           s3,         s3,         8*4*8     \n\t" \
  "vle8.v         v3,         (s4)                  \n\t" \
  "addi           s4,         s4,         8*4*8     \n\t" \
  "vle8.v         v4,         (s5)                  \n\t" \
  "addi           s5,         s5,         8*4*8     \n\t" \
  "vle8.v         v5,         (s6)                  \n\t" \
  "addi           s6,         s6,         8*4*8     \n\t" \
  "vle8.v         v6,         (s7)                  \n\t" \
  "addi           s7,         s7,         8*4*8     \n\t" \
  "vle8.v         v7,         (s8)                  \n\t" \
  "addi           s8,         s8,         8*4*8     \n\t" \
                                                          \
  "vle8.v         v12,        (t1)                  \n\t" \
  "addi           t1,         t1,         4*4*8     \n\t" \
  "vle8.v         v13,        (t2)                  \n\t" \
  "addi           t2,         t2,         4*4*8     \n\t" \
  "vle8.v         v14,        (t3)                  \n\t" \
  "addi           t3,         t3,         4*4*8     \n\t" \
                                                          \
  "vmadot         v16,        v0,         v8        \n\t" \
  "vmadot         v18,        v0,         v9        \n\t" \
  "vle8.v         v15,        (t4)                  \n\t" \
  "addi           t4,         t4,         4*4*8     \n\t" \
  "vmadot         v20,        v1,         v8        \n\t" \
  "vmadot         v22,        v1,         v9        \n\t" \
  "vle8.v         v0,         (s1)                  \n\t" \
  "addi           s1,         s1,         8*4*8     \n\t" \
  "vmadot         v24,        v2,         v8        \n\t" \
  "vmadot         v26,        v2,         v9        \n\t" \
  "vle8.v         v1,         (s2)                  \n\t" \
  "addi           s2,         s2,         8*4*8     \n\t" \
  "vmadot         v28,        v3,         v8        \n\t" \
  "vmadot         v30,        v3,         v9        \n\t" \
  "vle8.v         v2,         (s3)                  \n\t" \
  "addi           s3,         s3,         8*4*8     \n\t"


#define KERNEL16x8x8_M1                                   \
  "vmadot         v16,        v0,         v8        \n\t" \
  "vmadot         v18,        v0,         v9        \n\t" \
  "vle8.v         v15,        (t4)                  \n\t" \
  "addi           t4,         t4,         4*4*8     \n\t" \
  "vmadot         v20,        v1,         v8        \n\t" \
  "vmadot         v22,        v1,         v9        \n\t" \
  "vle8.v         v0,         (s1)                  \n\t" \
  "addi           s1,         s1,         8*4*8     \n\t" \
  "vmadot         v24,        v2,         v8        \n\t" \
  "vmadot         v26,        v2,         v9        \n\t" \
  "vle8.v         v1,         (s2)                  \n\t" \
  "addi           s2,         s2,         8*4*8     \n\t" \
  "vmadot         v28,        v3,         v8        \n\t" \
  "vmadot         v30,        v3,         v9        \n\t" \
  "vle8.v         v2,         (s3)                  \n\t" \
  "addi           s3,         s3,         8*4*8     \n\t"

#define KERNEL16x8x8_M2                                   \
  "vmadot         v16,        v4,         v10       \n\t" \
  "vmadot         v18,        v4,         v11       \n\t" \
  "vle8.v         v3,         (s4)                  \n\t" \
  "addi           s4,         s4,         8*4*8     \n\t" \
  "vmadot         v20,        v5,         v10       \n\t" \
  "vmadot         v22,        v5,         v11       \n\t" \
  "vle8.v         v4,         (s5)                  \n\t" \
  "addi           s5,         s5,         8*4*8     \n\t" \
  "vmadot         v24,        v6,         v10       \n\t" \
  "vmadot         v26,        v6,         v11       \n\t" \
  "vle8.v         v5,         (s6)                  \n\t" \
  "addi           s6,         s6,         8*4*8     \n\t" \
  "vmadot         v28,        v7,         v10       \n\t" \
  "vmadot         v30,        v7,         v11       \n\t" \
  "vle8.v         v6,         (s7)                  \n\t" \
  "addi           s7,         s7,         8*4*8     \n\t" \
  "vle8.v         v7,         (s8)                  \n\t" \
  "addi           s8,         s8,         8*4*8     \n\t" \
  "vle8.v         v8,         (t1)                  \n\t" \
  "addi           t1,         t1,         4*4*8     \n\t" \
  "vle8.v         v9,         (t2)                  \n\t" \
  "addi           t2,         t2,         4*4*8     \n\t" \
  "vle8.v         v10,        (t3)                  \n\t" \
  "addi           t3,         t3,         4*4*8     \n\t"

#define KERNEL16x8x8_M3                                   \
  "vmadot         v16,        v0,         v12       \n\t" \
  "vmadot         v18,        v0,         v13       \n\t" \
  "vle8.v         v11,        (t4)                  \n\t" \
  "addi           t4,         t4,         4*4*8     \n\t" \
  "vmadot         v20,        v1,         v12       \n\t" \
  "vmadot         v22,        v1,         v13       \n\t" \
  "vle8.v         v0,         (s1)                  \n\t" \
  "addi           s1,         s1,         8*4*8     \n\t" \
  "vmadot         v24,        v2,         v12       \n\t" \
  "vmadot         v26,        v2,         v13       \n\t" \
  "vle8.v         v1,         (s2)                  \n\t" \
  "addi           s2,         s2,         8*4*8     \n\t" \
  "vmadot         v28,        v3,         v12       \n\t" \
  "vmadot         v30,        v3,         v13       \n\t" \
  "vle8.v         v2,         (s3)                  \n\t" \
  "addi           s3,         s3,         8*4*8     \n\t"

#define KERNEL16x8x8_M4                                   \
  "vmadot         v16,        v4,         v14       \n\t" \
  "vmadot         v18,        v4,         v15       \n\t" \
  "vle8.v         v3,         (s4)                  \n\t" \
  "addi           s4,         s4,         8*4*8     \n\t" \
  "vmadot         v20,        v5,         v14       \n\t" \
  "vmadot         v22,        v5,         v15       \n\t" \
  "vle8.v         v4,         (s5)                  \n\t" \
  "addi           s5,         s5,         8*4*8     \n\t" \
  "vmadot         v24,        v6,         v14       \n\t" \
  "vmadot         v26,        v6,         v15       \n\t" \
  "vle8.v         v5,         (s6)                  \n\t" \
  "addi           s6,         s6,         8*4*8     \n\t" \
  "vmadot         v28,        v7,         v14       \n\t" \
  "vmadot         v30,        v7,         v15       \n\t" \
  "vle8.v         v6,         (s7)                  \n\t" \
  "addi           s7,         s7,         8*4*8     \n\t" \
  "vle8.v         v7,         (s8)                  \n\t" \
  "addi           s8,         s8,         8*4*8     \n\t" \
                                                          \
  "vle8.v         v12,        (t1)                  \n\t" \
  "addi           t1,         t1,         4*4*8     \n\t" \
  "vle8.v         v13,        (t2)                  \n\t" \
  "addi           t2,         t2,         4*4*8     \n\t" \
  "vle8.v         v14,        (t3)                  \n\t" \
  "addi           t3,         t3,         4*4*8     \n\t"

#define KERNEL16x8x8_E2                                   \
  "vmadot         v16,        v4,         v10       \n\t" \
  "vmadot         v18,        v4,         v11       \n\t" \
  "vle8.v         v3,         (s4)                  \n\t" \
  "addi           s4,         s4,         8*4*8     \n\t" \
  "vmadot         v20,        v5,         v10       \n\t" \
  "vmadot         v22,        v5,         v11       \n\t" \
  "vle8.v         v4,         (s5)                  \n\t" \
  "addi           s5,         s5,         8*4*8     \n\t" \
  "vmadot         v24,        v6,         v10       \n\t" \
  "vmadot         v26,        v6,         v11       \n\t" \
  "vle8.v         v5,         (s6)                  \n\t" \
  "addi           s6,         s6,         8*4*8     \n\t" \
  "vmadot         v28,        v7,         v10       \n\t" \
  "vmadot         v30,        v7,         v11       \n\t" \
  "vle8.v         v6,         (s7)                  \n\t" \
  "addi           s7,         s7,         8*4*8     \n\t"

#define KERNEL16x8x8_E3                                   \
  "vmadot         v16,        v0,         v12       \n\t" \
  "vmadot         v18,        v0,         v13       \n\t" \
  "vle8.v         v7,         (s8)                  \n\t" \
  "addi           s8,         s8,         8*4*8     \n\t" \
  "vmadot         v20,        v1,         v12       \n\t" \
  "vmadot         v22,        v1,         v13       \n\t" \
                                                          \
  "vmadot         v24,        v2,         v12       \n\t" \
  "vmadot         v26,        v2,         v13       \n\t" \
                                                          \
  "vmadot         v28,        v3,         v12       \n\t" \
  "vmadot         v30,        v3,         v13       \n\t"

#define KERNEL16x8x8_E4                                   \
  "vmadot         v16,        v4,         v14       \n\t" \
  "vmadot         v18,        v4,         v15       \n\t" \
                                                          \
  "vmadot         v20,        v5,         v14       \n\t" \
  "vmadot         v22,        v5,         v15       \n\t" \
                                                          \
  "vmadot         v24,        v6,         v14       \n\t" \
  "vmadot         v26,        v6,         v15       \n\t" \
                                                          \
  "vmadot         v28,        v7,         v14       \n\t" \
  "vmadot         v30,        v7,         v15       \n\t"
void Gemm_optmized(
  size_t M,
  size_t N,
  size_t K,
  const int8_t* a,
  const int8_t* b,
  int32_t* c) {

  size_t kc = K / 8;

    __asm__ volatile(
      "vsetvli        t0, x0, e32, m8               \n\t"
      "vxor.vv        v16, v16, v16                 \n\t"

      "addi           s1, %[a], 0                   \n\t"
      "addi           s2, %[a], 4*8                 \n\t"
      "addi           s3, %[a], 4*8*2               \n\t"
      "addi           s4, %[a], 4*8*3               \n\t"
      "addi           s5, %[a], 4*8*4               \n\t"
      "addi           s6, %[a], 4*8*5               \n\t"
      "addi           s7, %[a], 4*8*6               \n\t"
      "addi           s8, %[a], 4*8*7               \n\t"

      "addi           t1, %[w], 0                   \n\t"
      "addi           t2, %[w], 4*8                 \n\t"
      "add            t3, %[w], 4*8*2               \n\t"
      "addi           t4, %[w], 4*8*3               \n\t"
      "vsetvli        t0, x0, e8, m1                \n\t"

      "srli           t0, %[k], 2                   \n\t"
      "blez           t0, M16x32x8_TAIL%=           \n\t"

      KERNEL16x8x8_I

      "addi           t0, t0, -1                    \n\t"
      "blez           t0, M16x32x8_MAINLOOP_TAIL%=  \n\t"

      ".align 4                                     \n\t"
      "M16x32x8_MAINLOOP%=:                         \n\t"

      KERNEL16x8x8_M2 
      
      KERNEL16x8x8_M3 
      
      KERNEL16x8x8_M4 
      
      KERNEL16x8x8_M1

      "addi           t0, t0, -1                    \n\t"
      "bgtz           t0, M16x32x8_MAINLOOP%=       \n\t"

      "M16x32x8_MAINLOOP_TAIL%=:                    \n\t"

      KERNEL16x8x8_E2 
      
      KERNEL16x8x8_E3 
      
      KERNEL16x8x8_E4

      "M16x32x8_TAIL%=:                             \n\t"
      "andi           t0, %[k], 3                   \n\t"
      "blez           t0, M16x8_SAVERESULT%=        \n\t"

      ".align 4                                     \n\t"
      "M16x8_TAILLOOP%=:                            \n\t"

      "vle8.v         v8, (t1)                      \n\t"
      "addi           t1, t1, 2*4*8                 \n\t"
      "vle8.v         v9, (t2)                      \n\t"
      "addi           t2, t2, 2*4*8                 \n\t"

      "vle8.v         v0, (s1)                      \n\t"
      "addi           s1, s1, 4*4*8                 \n\t"
      "vle8.v         v1, (s2)                      \n\t"
      "addi           s2, s2, 4*4*8                 \n\t"
      "vle8.v         v2, (s3)                      \n\t"
      "addi           s3, s3, 4*4*8                 \n\t"
      "vle8.v         v3, (s4)                      \n\t"
      "addi           s4, s4, 4*4*8                 \n\t"

      "vmadot         v16, v0, v8                   \n\t"
      "vmadot         v18, v0, v9                   \n\t"
      "vmadot         v20, v1, v8                   \n\t"
      "vmadot         v22, v1, v9                   \n\t"
      "vmadot         v24, v2, v8                   \n\t"
      "vmadot         v26, v2, v9                   \n\t"
      "vmadot         v28, v3, v8                   \n\t"
      "vmadot         v30, v3, v9                   \n\t"

      "addi           t0, t0, -1                    \n\t"
      "bgtz           t0, M16x8_TAILLOOP%=          \n\t"

      "M16x8_SAVERESULT%=:                          \n\t"
      
      "vsetvli        t0, zero, e32, m8             \n\t"
      "addi           s1, %[C], 256                 \n\t"
      "vse32.v        v16, (%[C])                   \n\t"
      "vse32.v        v24, (s1)                     \n\t"

      "QUIT%=:                                      \n\t"
      : [w] "+r"(b)
      : [a] "r"(a), [C] "r"(c), [k] "r"(kc)
      : "cc", "t0", "t1", "t2", "t3", "t4", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8");
  return;
}

int main(){
  struct timespec time_start = {0, 0};
  struct timespec time_end = {0, 0};
  
  size_t M = 16;
  size_t N = 8;
  size_t K = 65536;

  int8_t A[M * K];
  int8_t B[K * N];
  int32_t C_ref[M * N];

  
  int8_t A_packed[M * K];
  int8_t B_packed[K * N];
  int32_t C[M * N];

  int8_t packB[K * N];


  clock_gettime(CLOCK_REALTIME, &time_start);
  Gemm_ref(M, N, K, A, B, C_ref);
  clock_gettime(CLOCK_REALTIME, &time_end);
  printf("gemm ref duration time = %.2fns\n", get_ns(time_end) - get_ns(time_start));
  
  
  clock_gettime(CLOCK_REALTIME, &time_start);
  Gemm_optmized(M, N, K, A_packed, B_packed, C);
  clock_gettime(CLOCK_REALTIME, &time_end);
  printf("gemm optmized duration time = %.2fns\n", get_ns(time_end) - get_ns(time_start));

  return 0;
}
