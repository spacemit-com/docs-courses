// riscv64-unknown-linux-gnu-gcc  -march=rv64gcv vmadot-gemm-demo.c -o gemm-vmadot-4x8x4

#include <assert.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

double get_ns(struct timespec t) { return (t.tv_sec * 1000000000 + t.tv_nsec); }


#define PRELOAD_8x16c8                        \
  "vle8.v           v0, (a1)            \n\t" \
  "addi             a1, a1, 4*8*2       \n\t" \
  "vle8.v           v1, (a2)            \n\t" \
  "addi             a2, a2, 4*8*2       \n\t" \
  "vle8.v           v3, (a3)            \n\t" \
  "addi             a3, a3, 4*8*2       \n\t" \
                                              \
  "vle8.v           v8, (s1)            \n\t" \
  "addi             s1, s1, 4*8*4       \n\t" \
  "vle8.v           v9, (s2)            \n\t" \
  "addi             s2, s2, 4*8*4       \n\t" \
  "vle8.v           v10, (s3)           \n\t" \
  "addi             s3, s3, 4*8*4       \n\t" \
  "vle8.v           v11, (s4)           \n\t" \
  "addi             s4, s4, 4*8*4       \n\t" \
  "vle8.v           v12, (s1)           \n\t" \
  "addi             s1, s1, 4*8*4       \n\t" \
  "vle8.v           v13, (s2)           \n\t" \
  "addi             s2, s2, 4*8*4       \n\t" \
  "vle8.v           v14, (s3)           \n\t" \
  "addi             s3, s3, 4*8*4       \n\t" \
                                              \
  "vmv.v.v          v2, v1              \n\t"

#define KERNEL_8x16c8s3_M1                    \
  "vle8.v           v4, (a1)            \n\t" \
  "addi             a1, a1, 4*8*2       \n\t" \
  "vle8.v           v5, (a2)            \n\t" \
  "addi             a2, a2, 4*8*2       \n\t" \
  "vle8.v           v7, (a3)            \n\t" \
  "addi             a3, a3, 4*8*2       \n\t" \
                                              \
  "vmv.v.v          v6, v5              \n\t" \
  "vmadot           v16, v0, v8         \n\t" \
  "vle8.v           v15, (s4)           \n\t" \
  "addi             s4, s4, 4*8*4       \n\t" \
  "vmadot           v24, v2, v8         \n\t" \
                                              \
  "vmadot           v18, v0, v9         \n\t" \
  "vle8.v           v8, (s1)            \n\t" \
  "addi             s1, s1, 7*8*16      \n\t" \
  "vmadot           v26, v2, v9         \n\t" \
                                              \
  "vmadot           v20, v0, v10        \n\t" \
  "vle8.v           v9, (s2)            \n\t" \
  "addi             s2, s2, 7*8*16      \n\t" \
  "vmadot           v28, v2, v10        \n\t" \
                                              \
  "vmadot           v22, v0, v11        \n\t" \
  "vle8.v           v10, (s3)           \n\t" \
  "addi             s3, s3, 7*8*16      \n\t" \
  "vmadot           v30, v2, v11        \n\t" \
                                              \
                                              \
  "vmadot1          v16, v0, v12        \n\t" \
  "vle8.v           v11, (s4)           \n\t" \
  "addi             s4, s4, 7*8*16      \n\t" \
  "vmadot1          v24, v2, v12        \n\t" \
                                              \
  "vmadot1          v18, v0, v13        \n\t" \
  "vle8.v           v12, (s1)           \n\t" \
  "addi             s1, s1, 4*8*4       \n\t" \
  "vmadot1          v26, v2, v13        \n\t" \
                                              \
  "vmadot1          v20, v0, v14        \n\t" \
  "vle8.v           v13, (s2)           \n\t" \
  "addi             s2, s2, 4*8*4       \n\t" \
  "vmadot1          v28, v2, v14        \n\t" \
                                              \
  "vmadot1          v22, v0, v15        \n\t" \
  "vle8.v           v14, (s3)           \n\t" \
  "addi             s3, s3, 4*8*4       \n\t" \
  "vmadot1          v30, v2, v15        \n\t" \
                                              \
                                              \
  "vmadot2          v16, v0, v8         \n\t" \
  "vle8.v           v15, (s4)           \n\t" \
  "addi             s4, s4, 4*8*4       \n\t" \
  "vmadot2          v24, v2, v8         \n\t" \
                                              \
  "vmadot2          v18, v0, v9         \n\t" \
  "vle8.v           v8, (s1)            \n\t" \
  "addi             s1, s1, 4*8*4       \n\t" \
  "vmadot2          v26, v2, v9         \n\t" \
                                              \
  "vmadot2          v20, v0, v10        \n\t" \
  "vle8.v           v9, (s2)            \n\t" \
  "addi             s2, s2, 4*8*4       \n\t" \
  "vmadot2          v28, v2, v10        \n\t" \
                                              \
  "vmadot2          v22, v0, v11        \n\t" \
  "vle8.v           v10, (s3)           \n\t" \
  "addi             s3, s3, 4*8*4       \n\t" \
  "vmadot2          v30, v2, v11        \n\t"


#define KERNEL_8x16c8s3_M2                    \
  "vle8.v           v0, (a1)            \n\t" \
  "addi             a1, a1, 4*8*2       \n\t" \
  "vle8.v           v1, (a2)            \n\t" \
  "addi             a2, a2, 4*8*2       \n\t" \
  "vle8.v           v3, (a3)            \n\t" \
  "addi             a3, a3, 4*8*2       \n\t" \
                                              \
  "vmv.v.v          v2, v1              \n\t" \
  "vmadot           v16, v4, v12        \n\t" \
  "vle8.v           v11, (s4)           \n\t" \
  "addi             s4, s4, 4*8*4       \n\t" \
  "vmadot           v24, v6, v12        \n\t" \
                                              \
  "vmadot           v18, v4, v13        \n\t" \
  "vle8.v           v12, (s1)           \n\t" \
  "addi             s1, s1, 7*8*16      \n\t" \
  "vmadot           v26, v6, v13        \n\t" \
                                              \
  "vmadot           v20, v4, v14        \n\t" \
  "vle8.v           v13, (s2)           \n\t" \
  "addi             s2, s2, 7*8*16      \n\t" \
  "vmadot           v28, v6, v14        \n\t" \
                                              \
  "vmadot           v22, v4, v15        \n\t" \
  "vle8.v           v14, (s3)           \n\t" \
  "addi             s3, s3, 7*8*16      \n\t" \
  "vmadot           v30, v6, v15        \n\t" \
                                              \
  "vmadot1          v16, v4, v8         \n\t" \
  "vle8.v           v15, (s4)           \n\t" \
  "addi             s4, s4, 7*8*16      \n\t" \
  "vmadot1          v24, v6, v8         \n\t" \
                                              \
  "vmadot1          v18, v4, v9         \n\t" \
  "vle8.v           v8, (s1)            \n\t" \
  "addi             s1, s1, 4*8*4       \n\t" \
  "vmadot1          v26, v6, v9         \n\t" \
                                              \
  "vmadot1          v20, v4, v10        \n\t" \
  "vle8.v           v9, (s2)            \n\t" \
  "addi             s2, s2, 4*8*4       \n\t" \
  "vmadot1          v28, v6, v10        \n\t" \
                                              \
  "vmadot1          v22, v4, v11        \n\t" \
  "vle8.v           v10, (s3)           \n\t" \
  "addi             s3, s3, 4*8*4       \n\t" \
  "vmadot1          v30, v6, v11        \n\t" \
                                              \
  "vmadot2          v16, v4, v12        \n\t" \
  "vle8.v           v11, (s4)           \n\t" \
  "addi             s4, s4, 4*8*4       \n\t" \
  "vmadot2          v24, v6, v12        \n\t" \
                                              \
  "vmadot2          v18, v4, v13        \n\t" \
  "vle8.v           v12, (s1)           \n\t" \
  "addi             s1, s1, 4*8*4       \n\t" \
  "vmadot2          v26, v6, v13        \n\t" \
                                              \
  "vmadot2          v20, v4, v14        \n\t" \
  "vle8.v           v13, (s2)           \n\t" \
  "addi             s2, s2, 4*8*4       \n\t" \
  "vmadot2          v28, v6, v14        \n\t" \
                                              \
  "vmadot2          v22, v4, v15        \n\t" \
  "vle8.v           v14, (s3)           \n\t" \
  "addi             s3, s3, 4*8*4       \n\t" \
  "vmadot2          v30, v6, v15        \n\t"



#define KERNEL_8x16c8s3_E2                    \
  "vmadot           v16, v4, v12        \n\t" \
  "vle8.v           v11, (s4)           \n\t" \
  "addi             s4, s4, 4*8*4       \n\t" \
  "vmadot           v24, v6, v12        \n\t" \
                                              \
  "vmadot           v18, v4, v13        \n\t" \
  "vle8.v           v12, (s1)           \n\t" \
  "addi             s1, s1, 7*8*16      \n\t" \
  "vmadot           v26, v6, v13        \n\t" \
                                              \
  "vmadot           v20, v4, v14        \n\t" \
  "vle8.v           v13, (s2)           \n\t" \
  "addi             s2, s2, 7*8*16      \n\t" \
  "vmadot           v28, v6, v14        \n\t" \
                                              \
  "vmadot           v22, v4, v15        \n\t" \
  "vle8.v           v14, (s3)           \n\t" \
  "addi             s3, s3, 7*8*16      \n\t" \
  "vmadot           v30, v6, v15        \n\t" \
                                              \
  "vmadot1          v16, v4, v8         \n\t" \
  "vle8.v           v15, (s4)           \n\t" \
  "addi             s4, s4, 7*8*16      \n\t" \
  "vmadot1          v24, v6, v8         \n\t" \
                                              \
  "vmadot1          v18, v4, v9         \n\t" \
  "vmadot1          v26, v6, v9         \n\t" \
                                              \
  "vmadot1          v20, v4, v10        \n\t" \
  "vmadot1          v28, v6, v10        \n\t" \
                                              \
  "vmadot1          v22, v4, v11        \n\t" \
  "vmadot1          v30, v6, v11        \n\t" \
                                              \
  "vmadot2          v16, v4, v12        \n\t" \
  "vmadot2          v24, v6, v12        \n\t" \
                                              \
  "vmadot2          v18, v4, v13        \n\t" \
  "vmadot2          v26, v6, v13        \n\t" \
                                              \
  "vmadot2          v20, v4, v14        \n\t" \
  "vmadot2          v28, v6, v14        \n\t" \
                                              \
  "vmadot2          v22, v4, v15        \n\t" \
  "vmadot2          v30, v6, v15        \n\t"




#define KERNEL_8x16c8s3_T1                    \
  "vle8.v           v15, (s4)           \n\t" \
  "addi             s4, s4, 4*8*4       \n\t" \
  "vle8.v           v4, (s1)            \n\t" \
  "addi             s1, s1, 7*8*16      \n\t" \
  "vle8.v           v5, (s2)            \n\t" \
  "addi             s2, s2, 7*8*16      \n\t" \
  "vle8.v           v6, (s3)            \n\t" \
  "addi             s3, s3, 7*8*16      \n\t" \
  "vle8.v           v7, (s4)            \n\t" \
  "addi             s4, s4, 7*8*16      \n\t" \
                                              \
  "vmadot           v16, v0, v8         \n\t" \
  "vmadot           v24, v2, v8         \n\t" \
                                              \
  "vmadot           v18, v0, v9         \n\t" \
  "vmadot           v26, v2, v9         \n\t" \
                                              \
  "vmadot           v20, v0, v10        \n\t" \
  "vmadot           v28, v2, v10        \n\t" \
                                              \
  "vmadot           v22, v0, v11        \n\t" \
  "vmadot           v30, v2, v11        \n\t" \
                                              \
                                              \
  "vmadot1          v16, v0, v12        \n\t" \
  "vmadot1          v24, v2, v12        \n\t" \
                                              \
  "vmadot1          v18, v0, v13        \n\t" \
  "vmadot1          v26, v2, v13        \n\t" \
                                              \
  "vmadot1          v20, v0, v14        \n\t" \
  "vmadot1          v28, v2, v14        \n\t" \
                                              \
  "vmadot1          v22, v0, v15        \n\t" \
  "vmadot1          v30, v2, v15        \n\t" \
                                              \
                                              \
  "vmadot2          v16, v0, v4         \n\t" \
  "vmadot2          v24, v2, v4         \n\t" \
                                              \
  "vmadot2          v18, v0, v5         \n\t" \
  "vmadot2          v26, v2, v5         \n\t" \
                                              \
  "vmadot2          v20, v0, v6         \n\t" \
  "vmadot2          v28, v2, v6         \n\t" \
                                              \
  "vmadot2          v22, v0, v7         \n\t" \
  "vmadot2          v30, v2, v7         \n\t"

static void conv3x3_s1d1_m8n16_ref(
    size_t K,
    const int8_t* a,
    const int8_t* w,
    int32_t* c,
    size_t a_row_stride) {
    
    for (size_t m = 0; m < 8; ++m) {
      for (size_t n = 0; n < 16; ++n) {
        int32_t acc = 0;
        for (size_t kh = 0; kh < 3; ++kh) {
          for (size_t kw = 0; kw < 3; ++kw) {
            const int8_t* lhs = a + m * K + kh * a_row_stride + kw * K;
            const int8_t* rhs = w + n * 3 * 3 * K + kh * 3 * K + kw * K;
            for (size_t ic = 0; ic < K; ++ic) {
              int8_t lhs_val = lhs[ic]; 
              int8_t rhs_val = rhs[ic];
              acc += lhs_val * rhs_val; 
            }
          }
        }
        c[m * 16 + n] = acc;
      }
    }

}

static void conv3x3_s1d1_m8n16(
    size_t K,
    const int8_t* a,
    const int8_t* w,
    int32_t* c,
    size_t a_row_stride,
    size_t a_tile_stride) {
    
    size_t kc = K / 8;

#ifdef __riscv_vector

    __asm__ volatile(
      "li                   t3, 3                            \n\t"
      "vsetvli              t0, zero, e32, m8                \n\t"
      "vxor.vv              v16, v16, v16                    \n\t"
      "vxor.vv              v24, v24, v24                    \n\t"

      "vsetvli              t0, zero, e8, m1                 \n\t"
      "START%=:                                              \n\t"
      // set weight ptr
      "addi                 s1, %[W], 0                      \n\t"
      "addi                 s2, %[W], 4*8                    \n\t"
      "addi                 s3, %[W], 4*8*2                  \n\t"
      "addi                 s4, %[W], 4*8*3                  \n\t"
      // set feature ptr
      "addi                 a1, %[A], 0                      \n\t"
      "addi                 a2, %[A], 4*8                    \n\t"
      "add                  a3, %[A], %[ATS]                 \n\t"

      "add                  %[A], %[A], %[ARS]               \n\t"

      "srli                 t2, %[KC], 2                     \n\t"
      "blez                 t2, TAIL_8x16c8s3_KC1%=          \n\t"

      PRELOAD_8x16c8

      "addi                 t2, t2, -1                       \n\t"
      "blez                 t2, TAIL_8x16c8s3_KC4%=          \n\t"


      "MAINLOOP_8x16c8s3_KC4%=:                              \n\t"

      KERNEL_8x16c8s3_M1  KERNEL_8x16c8s3_M2

      KERNEL_8x16c8s3_M1  KERNEL_8x16c8s3_M2

      "addi                 t2, t2, -1                       \n\t"
      "bgtz                 t2, MAINLOOP_8x16c8s3_KC4%=      \n\t"

      "TAIL_8x16c8s3_KC4%=:                                  \n\t"

      KERNEL_8x16c8s3_M1  KERNEL_8x16c8s3_M2

      KERNEL_8x16c8s3_M1  KERNEL_8x16c8s3_E2

      "TAIL_8x16c8s3_KC1%=:                                  \n\t"
      "andi                 t2, %[KC], 3                     \n\t"
      "blez                 t2, SLIDEDOWN%=                  \n\t"

      "TAILLOOP_8x16c8s3_KC1%=:                              \n\t"


      PRELOAD_8x16c8

      KERNEL_8x16c8s3_T1

      "addi                 t2, t2, -1                       \n\t"
      "bgtz                 t2, TAILLOOP_8x16c8s3_KC1%=      \n\t"

      "SLIDEDOWN%=:                                          \n\t"
      "addi                 %[W], %[W], 3*8*16               \n\t"
      "addi                 t3, t3, -1                       \n\t"
      "bgtz                 t3, START%=                      \n\t"

      "POST_PROCESS%=:                                       \n\t"

      "QUIT%=:                                               \n\t"

      : [ C ] "+r"(c), [ A ] "+r"(a), [W] "+r"(w)
      : [ KC ] "r"(kc), [ ATS ] "r"(a_tile_stride), [ ARS ] "r"(a_row_stride)
      : "cc", "t0", "t1", "t2", "t3",
        "a1", "a2", "a3",
        "s1", "s2", "s3", "s4", "s5");
#endif
  return ;
}
int main(){
  struct timespec time_start = {0, 0};
  struct timespec time_end = {0, 0};
  
  size_t IH = 3;
  size_t IW = 10;
  size_t IC = 4096;
  size_t OC = 16;
  size_t kh = 3;
  size_t kw = 3;
  size_t OH = 1;
  size_t OW = 8;

  int8_t A[IH  * IW * IC];
  int8_t A_packed[IH  * ((IW + 7) / 8 + 1)* 8 * IC * 2];
  int8_t W[kh * kw * IC * OC];

  int32_t C[(IH - 2) * (IW - 2) * IC];
  int32_t C_ref[(IH - 2) * (IW - 2) * IC];

  size_t a_tile_stride = 8 * IC;
  size_t a_row_stride = ((IW + 7) + 1) / 8 * 8 * IC;
 
  

  clock_gettime(CLOCK_REALTIME, &time_start);
  conv3x3_s1d1_m8n16_ref(IC, A, W, C, IW * IC);
  clock_gettime(CLOCK_REALTIME, &time_end);
  printf("gemm ref duration time = %.2fns\n", get_ns(time_end) - get_ns(time_start));
  
  
  clock_gettime(CLOCK_REALTIME, &time_start);
  conv3x3_s1d1_m8n16(IC, A_packed, W, C_ref, a_row_stride, a_tile_stride);
  clock_gettime(CLOCK_REALTIME, &time_end);
  printf("gemm optmized duration time = %.2fns\n", get_ns(time_end) - get_ns(time_start));

  return 0;
}


