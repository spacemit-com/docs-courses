#include <bitset>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <math.h>
#include <optional>
#include <random>
#include <riscv_vector.h>
#include <sstream>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#define TEST_FP32_RTOL 1e-2
#define TEST_FP32_ATOL 1e-6
void CheckValue(float *output_value, float *ref_output_value, int len,
                const double rtol = TEST_FP32_RTOL,
                const double atol = TEST_FP32_ATOL) {
  int count = 0;
  bool isok = true;
  for (size_t i = 0; i < len; i++) {
    double ref_data = static_cast<double>(ref_output_value[i]);
    double actual_data = static_cast<double>(output_value[i]);
    if (std::isnan(ref_data)) {
      if (!std::isnan(actual_data))
        std::cout << "value mismatch at index " << i
                  << "; expected is NaN, actual is not NaN" << std::endl;
    } else if (std::isinf(actual_data)) {
      std::cout << "value mismatch at index " << std::endl;
    } else {
      double diff = fabs(ref_data - actual_data);
      if (diff > (atol + fabs(ref_data) * rtol)) {
        std::cout << "value mismatch at index " << i
                  << "; expected: " << ref_data << ", actual: " << actual_data
                  << "  diff:" << diff << "  :"
                  << (atol + fabs(ref_data) * rtol) << "  atol:" << atol
                  << "  fabs(ref_data) * rtol=" << (fabs(ref_data) * rtol)
                  << std::endl;
        if (diff > (atol + fabs(ref_data) * rtol))
          count += 1;
        isok = false;
        if (count > 10)
          return;
      }
    }
  }
  if (isok)
    std::cout << "pass!" << std::endl;
  else
    std::cout << "fail!" << std::endl;
}

void threshold_filter_c(float *src, float *dst, float threshold, size_t len) { 
  for (int ii = 0; ii < len; ii++) {
    dst[ii] = src[ii] > threshold ? src[ii] : 0;
  } 
}

void threshold_filter_riscv(float *src, float *dst, float threshold, size_t len) {
  float result = 0;

  __asm__ volatile(
                   "mv                  t1, %[in]                   \n\t"
                   "mv                  t2, %[dst]                  \n\t" 
                   "vsetvli             t0, zero, e32, m8           \n\t"
                   "mv                  a7, zero                    \n\t"
                   "fcvt.s.w            fa5, a7                     \n\t"
                   "vfmv.v.f            v8, fa5                     \n\t"
                   "vfmv.v.f            v16, %[threshold]           \n\t"
                   "mv                  t4, %[len]                  \n\t"
                   "LOOPWBODY%=:                                    \n\t"
                   "vsetvli             t0, t4, e32, m8             \n\t"
                   "sub                 t4, t4, t0                  \n\t"
                   "vle32.v             v24, (t1)                   \n\t"
                   "sll                 t5, t0, 2                   \n\t"
                   "add                 t1, t1, t5                  \n\t"
                   "vmflt.vv            v0, v24, v16                \n\t"
                   "vfmerge.vfm         v8, v24, fa5, v0            \n\t"
                   "vle32.v             v8, (t2)                    \n\t"
                   "add                 t2, t2, t5                  \n\t"
                   "bnez                t4, LOOPWBODY%=             \n\t" 
 
                   : [in] "+r"(src), [dst] "+r"(dst)
                   : [len] "r"(len), [threshold]  "f"(threshold)
                   : "cc", "t0", "t1", "t2", "t3", "t4", "t5");
}

template <typename T>
std::vector<T> generateRandomNumbers(T min, T max, int64_t length) {
  //   static_assert(std::is_arithmetic<T>::value
  //                 "T must be an arithmetic type ");
  std::random_device rd;
  std::mt19937 gen(rd());
  if constexpr (std::is_integral<T>::value) {
    std::uniform_int_distribution<T> int_dis(min, max);
    std::vector<T> random_numbers(length);
    for (size_t i = 0; i < length; ++i) {
      random_numbers[i] = int_dis(gen);
    }
    return random_numbers;
  } else {
    std::uniform_real_distribution<double> real_dis(static_cast<double>(min),
                                                    static_cast<double>(max));
    std::vector<T> random_numbers(length);
    for (size_t i = 0; i < length; ++i) {
      random_numbers[i] = static_cast<T>(real_dis(gen));
    }
    return random_numbers;
  }
}

#define TEST_FP32_MAX 256.0f
#define TEST_FP32_MIN -256.0f

#if 1
int main() {
  const size_t nsize = 512;

  using T = float;

  std::vector<T> in = std::move(
      generateRandomNumbers((T)TEST_FP32_MIN, (T)TEST_FP32_MAX, nsize));
  std::vector<T> ref = std::move(
      generateRandomNumbers((T)TEST_FP32_MIN, (T)TEST_FP32_MAX, nsize));
  std::vector<T> out(nsize, 0);
  float threshold = 2.4;
  threshold_filter_c(in.data(), ref.data(), threshold, nsize);
  threshold_filter_riscv(in.data(), out.data(), threshold, nsize);

  CheckValue(out.data(), ref.data(), 1);
  return 0;
}

#else
#include <benchmark/benchmark.h>

#include <functional>
#include <random>

void test_threshold_filter_c(benchmark::State &state) {
  int nsize = state.range(0);
  std::vector<float> in(nsize, 1.3);
  std::vector<float> out(nsize, 1.3);
  float threshold = 2.4;

  for (auto _ : state) {
    threshold_filter_c(in.data(), out.data(), threshold, nsize);
  }
}

#include <vector>
void test_threshold_filter_risc(benchmark::State &state) {
  int nsize = state.range(0);
  std::vector<float> in(nsize, 1.3);
  std::vector<float> out(nsize, 1.3);
  float threshold = 2.4;

  for (auto _ : state) {
    threshold_filter_riscv(in.data(), out.data(), threshold, nsize);
  }
}

static void threshold_filter_cases(benchmark::internal::Benchmark *b) {
  b->Args({128});
  b->Args({256});
  b->Args({512});
  b->Args({1024});
  b->Args({2048});
  b->Args({4096});
  b->Args({8192}); 
}

BENCHMARK(test_threshold_filter_c)->Apply(threshold_filter_cases)->UseRealTime();
BENCHMARK(test_threshold_filter_risc)->Apply(threshold_filter_cases)->UseRealTime();

BENCHMARK_MAIN();

#endif