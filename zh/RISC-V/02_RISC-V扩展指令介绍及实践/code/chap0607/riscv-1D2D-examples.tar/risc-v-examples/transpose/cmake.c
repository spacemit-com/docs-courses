./configure --host=~/gcc/spacemit-gcc-linux-glibc-x86_64-jdsk-v0.2.1-20230814T174310/bin/riscv64-unknown-linux-gnu-g++  --prefix=/home/liaolinyu/projects/0-kernel/mtests/FFT/fftwlib/ 

 cmake ../ -DCMAKE_TOOLCHAIN_FILE=../../../common/cmake/linux_riscv64.toolchain.cmake  -DRISCV64_SPACEMIT_IME_SPEC=RISCV64_SPACEMIT_IME1   -DSPINE_KERNEL_BUILD_TESTS=ON  -DSPINE_KERNEL_BUILD_BENCHMARKS=ON 






#if(SPINE_KERNEL_BUILD_GOOGLE_TEST)
  include(FetchContent)
  FetchContent_Declare(
    googletest

    # Specify the commit you depend on and update it regularly.
    URL https://github.com/google/googletest/archive/5376968f6948923e2411081fd9372e71a59d8e77.zip
  )

#if(SPINE_KERNEL_BUILD_BENCHMARKS)
  set(gtest_force_shared_crt ON CACHE BOOL "" FORCE)
  FetchContent_MakeAvailable(googletest)


  target_link_libraries(main_test gtest_main)


  // fft_iterative_riscv(in, N);
  //   printf("FFT Output (float):\n");
  //   for (int i = 0; i < N; i++) {
  //     printf("out[%d] = %f + %fi    self[%d] = %f + %fi\n", i, out[i][0],
  //            out[i][1], i, in[i][0], in[i][1]);
  //   }

