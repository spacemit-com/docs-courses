#include <bitset>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <math.h>
#include <optional>
#include <random>
#include <riscv_vector.h>
#include <sstream>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#define TEST_FP32_RTOL 1e-2
#define TEST_FP32_ATOL 1e-6
void CheckValue(float *output_value, float *ref_output_value, int len,
                const double rtol = TEST_FP32_RTOL,
                const double atol = TEST_FP32_ATOL) {
  int count = 0;
  bool isok = true;
  for (size_t i = 0; i < len; i++) {
    double ref_data = static_cast<double>(ref_output_value[i]);
    double actual_data = static_cast<double>(output_value[i]);
    if (std::isnan(ref_data)) {
      if (!std::isnan(actual_data))
        std::cout << "value mismatch at index " << i
                  << "; expected is NaN, actual is not NaN" << std::endl;
    } else if (std::isinf(actual_data)) {
      std::cout << "value mismatch at index " << std::endl;
    } else {
      double diff = fabs(ref_data - actual_data);
      if (diff > (atol + fabs(ref_data) * rtol)) {
        std::cout << "value mismatch at index " << i
                  << "; expected: " << ref_data << ", actual: " << actual_data
                  << "  diff:" << diff << "  :"
                  << (atol + fabs(ref_data) * rtol) << "  atol:" << atol
                  << "  fabs(ref_data) * rtol=" << (fabs(ref_data) * rtol)
                  << std::endl;
        if (diff > (atol + fabs(ref_data) * rtol))
          count += 1;
        isok = false;
        if (count > 10)
          return;
      }
    }
  }
  if (isok)
    std::cout << "pass!" << std::endl;
  else
    std::cout << "fail!" << std::endl;
}

void image_image_shift_c(float *src, float *dst, size_t width, size_t height,
                         int shift) {
  int left = 0;
  int right = width;
  if (shift < 0) {
    right = width + shift;
  }
  if (shift > 0) {
    left = shift;
  }

  for (int h = 0; h < height; h++) {
    for (int w = 0; w < left; w++) {
      dst[h * width + w] = 0;
    }
    for (int w = left; w < right; w++) {
      dst[h * width + w] = src[h * width + w - left];
    }
    for (int w = right; w < width; w++) {
      dst[h * width + w] = 0;
    }
  }
}

void image_image_shift_riscv(float *src, float *dst, size_t width,
                             size_t height, int shift) {
  int left = 0;
  int right = width;
  if (shift < 0) {
    right = width + shift;
  }
  if (shift > 0) {
    left = shift;
  }
  size_t len0 = left;
  size_t len1 = right - left;
  size_t len2 = width - right;
  size_t src_offset = width * sizeof(float);
  __asm__ volatile(
                   "vsetvli             t0, zero, e32, m8           \n\t"
                   "mv                  a7, zero                    \n\t"
                   "fcvt.s.w            fa5, a7                     \n\t"
                   "vfmv.v.f            v0, fa5                     \n\t"
                   "mv                  t3, %[src_offset]           \n\t"
                   "mv                  t2, %[dst]                  \n\t"
                   "LOOPH%=:                                        \n\t"
                   "mv                  t1, %[in]                   \n\t"

                   "mv                  t4, %[len0]                 \n\t"
                   "LOOPWLEFT%=:                                    \n\t"
                   "vsetvli             t0, t4, e32, m8             \n\t"
                   "sub                 t4, t4, t0                  \n\t"
                   "sll                 t5, t0, 2                   \n\t"
                   "vse32.v             v0, (t2)                    \n\t"
                   "add                 t2, t2, t5                  \n\t"
                   "bnez                t4, LOOPWLEFT%=             \n\t"

                   "mv                  t4, %[len1]                 \n\t"
                   "LOOPWBODY%=:                                    \n\t"
                   "vsetvli             t0, t4, e32, m8             \n\t"
                   "sub                 t4, t4, t0                  \n\t"
                   "vle32.v             v8, (t1)                    \n\t"
                   "sll                 t5, t0, 2                   \n\t"
                   "add                 t1, t1, t5                  \n\t"
                   "vse32.v             v8, (t2)                    \n\t"
                   "add                 t2, t2, t5                  \n\t"
                   "bnez                t4, LOOPWBODY%=             \n\t"
                   
                   "mv                  t4, %[len2]                 \n\t"
                   "LOOPWRIGHT%=:                                   \n\t"
                   "vsetvli             t0, t4, e32, m8             \n\t"
                   "sub                 t4, t4, t0                  \n\t"
                   "sll                 t5, t0, 2                   \n\t"
                   "vse32.v             v0, (t2)                    \n\t"
                   "add                 t2, t2, t5                  \n\t"
                   "bnez                t4, LOOPWRIGHT%=            \n\t"

                   "add                 %[in], %[in], t3            \n\t"
                   "addi                %[height], %[height], -1    \n\t"
                   "bnez                %[height], LOOPH%=          \n\t"
                   : [in] "+r"(src), [dst] "+r"(dst)
                   : [len0] "r"(len0), [len1] "r"(len1), [len2] "r"(len2), [height] "r"(height),
                      [src_offset] "r"(src_offset)
                   : "cc", "t0", "t1", "t2", "t3", "t4", "t5");
}

template <typename T>
std::vector<T> generateRandomNumbers(T min, T max, int64_t length) {
  //   static_assert(std::is_arithmetic<T>::value
  //                 "T must be an arithmetic type ");
  std::random_device rd;
  std::mt19937 gen(rd());
  if constexpr (std::is_integral<T>::value) {
    std::uniform_int_distribution<T> int_dis(min, max);
    std::vector<T> random_numbers(length);
    for (size_t i = 0; i < length; ++i) {
      random_numbers[i] = int_dis(gen);
    }
    return random_numbers;
  } else {
    std::uniform_real_distribution<double> real_dis(static_cast<double>(min),
                                                    static_cast<double>(max));
    std::vector<T> random_numbers(length);
    for (size_t i = 0; i < length; ++i) {
      random_numbers[i] = static_cast<T>(real_dis(gen));
    }
    return random_numbers;
  }
}

#define TEST_FP32_MAX 256.0f
#define TEST_FP32_MIN -256.0f

#if 1
int main() {
  const size_t width = 512;
  const size_t height = 512;
  int shift = -3;
  const size_t nsize = width * height;

  using T = float;

  std::vector<T> in = std::move(
      generateRandomNumbers((T)TEST_FP32_MIN, (T)TEST_FP32_MAX, nsize));
  std::vector<T> ref = std::move(
      generateRandomNumbers((T)TEST_FP32_MIN, (T)TEST_FP32_MAX, nsize));
  std::vector<T> out(nsize, 0);
  image_image_shift_c(in.data(), ref.data(), width, height, shift);
  image_image_shift_riscv(in.data(), out.data(), width, height, shift);

  CheckValue(out.data(), ref.data(), nsize);
  return 0;
}

#else
#include <benchmark/benchmark.h>

#include <functional>
#include <random>

void test_image_shift_c(benchmark::State &state) {
  int width = state.range(0);
  int height = state.range(1);
  int shift = state.range(2);
  const size_t nsize = width * height;
  std::vector<float> in(nsize, 1.3);
  std::vector<float> out(nsize, 1.3);

  for (auto _ : state) {
    image_image_shift_c(in.data(), out.data(), width, height, shift);
  }
}

#include <vector>
void test_image_shift_risc(benchmark::State &state) {
  int width = state.range(0);
  int height = state.range(1);
  int shift = state.range(2);
  const size_t nsize = width * height;
  std::vector<float> in(nsize, 1.3);
  std::vector<float> out(nsize, 1.3);

  for (auto _ : state) {
    image_image_shift_riscv(in.data(), out.data(), width, height, shift);
  }
}

static void image_shift_cases(benchmark::internal::Benchmark *b) {
  b->Args({8, 256, 8});
  b->Args({8, 512, 8});
  b->Args({8, 1024, 8});
  b->Args({256, 256, 8});
  b->Args({512, 512, 8});
  b->Args({1024, 1024, 8});
  b->Args({8, 256, -8});
  b->Args({8, 512, -8});
  b->Args({8, 1024, -8});
  b->Args({256, 256, -8});
  b->Args({512, 512, -8});
  b->Args({1024, 1024, -8});
}

BENCHMARK(test_image_shift_c)->Apply(image_shift_cases)->UseRealTime();
BENCHMARK(test_image_shift_risc)->Apply(image_shift_cases)->UseRealTime();

BENCHMARK_MAIN();

#endif