#!/bin/bash
QEMU_ROOT_PATH=/home/liaolinyu/gcc/jdsk-qemu
${QEMU_ROOT_PATH}/bin/qemu-riscv64 -L ${RISCV_ROOT_PATH}/sysroot -cpu max,vlen=256,elen=64,vext_spec=v1.0 $@