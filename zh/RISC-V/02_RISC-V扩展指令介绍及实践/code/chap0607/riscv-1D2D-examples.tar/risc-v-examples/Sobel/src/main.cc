

#include <bitset>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <math.h>
#include <optional>
#include <random>
#include <riscv_vector.h>
#include <sstream>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>
#define TEST_FP32_MAX 256.0f
#define TEST_FP32_MIN -256.0f
#define TEST_FP32_RTOL 1e-2
#define TEST_FP32_ATOL 1e-6

template <typename T>
std::vector<T> generateRandomNumbers(T min, T max, int64_t length) {
  //   static_assert(std::is_arithmetic<T>::value
  //                 "T must be an arithmetic type ");
  std::random_device rd;
  std::mt19937 gen(rd());
  if constexpr (std::is_integral<T>::value) {
    std::uniform_int_distribution<T> int_dis(min, max);
    std::vector<T> random_numbers(length);
    for (size_t i = 0; i < length; ++i) {
      random_numbers[i] = int_dis(gen);
    }
    return random_numbers;
  } else {
    std::uniform_real_distribution<double> real_dis(static_cast<double>(min),
                                                    static_cast<double>(max));
    std::vector<T> random_numbers(length);
    for (size_t i = 0; i < length; ++i) {
      random_numbers[i] = static_cast<T>(real_dis(gen));
    }
    return random_numbers;
  }
}

// 正确性验证
void CheckValue(float *output_value, float *ref_output_value, int len,
                const double rtol = TEST_FP32_RTOL,
                const double atol = TEST_FP32_ATOL) {
  int count = 0;
  bool isok = true;
  for (size_t i = 0; i < len; i++) {
    double ref_data = static_cast<double>(ref_output_value[i]);
    double actual_data = static_cast<double>(output_value[i]);
    if (std::isnan(ref_data)) {
      if (!std::isnan(actual_data))
        std::cout << "value mismatch at index " << i
                  << "; expected is NaN, actual is not NaN" << std::endl;
    } else if (std::isinf(actual_data)) {
      std::cout << "value mismatch at index " << std::endl;
    } else {
      double diff = fabs(ref_data - actual_data);
      if (diff > (atol + fabs(ref_data) * rtol)) {
        std::cout << "value mismatch at index " << i
                  << "; expected: " << ref_data << ", actual: " << actual_data
                  << "  diff:" << diff << "  :"
                  << (atol + fabs(ref_data) * rtol) << "  atol:" << atol
                  << "  fabs(ref_data) * rtol=" << (fabs(ref_data) * rtol)
                  << std::endl;
        if (diff > (atol + fabs(ref_data) * rtol))
          count += 1;
        isok = false;
        if (count > 10)
          return;
      }
    }
  }
  if (isok)
    std::cout << "pass!" << std::endl;
  else
    std::cout << "fail!" << std::endl;
}

void image_sobel_c(float *input, float *output, size_t width, size_t height) {
  int Gx[3][3] = {{-1, 0, 1}, {-2, 0, 2}, {-1, 0, 1}};
  int Gy[3][3] = {{-1, -2, -1}, {0, 0, 0}, {1, 2, 1}};
  for (int y = 1; y < height - 1; y++) {
    for (int x = 1; x < width - 1; x++) {
      float sumX = 0, sumY = 0;
      for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
          sumX += input[(y + i) * width + (x + j)] * Gx[i + 1][j + 1];
          sumY += input[(y + i) * width + (x + j)] * Gy[i + 1][j + 1];
        }
      }
      output[y * width + x] =  (sqrt(sumX * sumX + sumY * sumY) / 4);
    }
  }
}

void image_sobel_riscv(float *input, float *output, size_t width,
                       size_t height) {
  if (width < 3 || height < 3)
    return;
  float *src00 = &input[0 * width + 0];
  float *src01 = &input[0 * width + 1];
  float *src02 = &input[0 * width + 2];
  float *src10 = &input[1 * width + 0];
  float *src11 = &input[1 * width + 1];
  float *src12 = &input[1 * width + 2];
  float *src20 = &input[2 * width + 0];
  float *src21 = &input[2 * width + 1];
  float *src22 = &input[2 * width + 2];

  size_t max_len = width - 2;

  float *dst = &output[1 * width + 1];
  size_t h_max = height - 2;
  float beta = 1.0 / 4; 
  __asm__ volatile(
      "mv                  t3, %[width]                   \n\t"
      "slli                t3, t3, 2                      \n\t"
      "LOOPH%=:                                           \n\t"
      "mv                  t2, %[dst]                     \n\t"
      "addi                t4, %[width], -2               \n\t"
      "LOOPW%=:                                           \n\t"
      "vsetvli             t0, t4, e32, m2                \n\t"
      "sub                 t4, t4, t0                     \n\t"
      "vle32.v             v0, (%[src00])                 \n\t"
      "vle32.v             v2, (%[src01])                 \n\t"
      "vle32.v             v4, (%[src02])                 \n\t"
      "vle32.v             v6, (%[src10])                 \n\t"
      "vle32.v             v10, (%[src12])                \n\t"
      "vle32.v             v12, (%[src20])                \n\t"
      "vle32.v             v14, (%[src21])                \n\t"
      "vle32.v             v16, (%[src22])                \n\t"
      "vfsub.vv            v18, v12, v0                   \n\t"
      "vfadd.vv            v18, v18, v16                  \n\t"
      "vfsub.vv            v18, v18, v4                   \n\t"
      "vfadd.vv            v14, v14, v14                  \n\t"
      "vfadd.vv            v2, v2, v2                     \n\t"
      "vfadd.vv            v18, v18, v14                  \n\t"
      "vfsub.vv            v18, v18, v2                   \n\t"
      "vfsub.vv            v20, v4, v0                    \n\t"
      "vfadd.vv            v20, v20, v16                  \n\t"
      "vfsub.vv            v20, v20, v12                  \n\t"
      "vfadd.vv            v10, v10, v10                  \n\t"
      "vfadd.vv            v6, v6, v6                     \n\t"
      "vfadd.vv            v20, v20, v10                  \n\t"
      "vfsub.vv            v20, v20, v6                   \n\t"
      "vfmul.vv            v18, v18, v18                  \n\t"
      "vfmul.vv            v20, v20, v20                  \n\t"
      "vfadd.vv            v18, v18, v20                  \n\t"
      "vfsqrt.v            v20, v18                       \n\t"
      "vfmul.vf            v0, v20, %[beta]               \n\t"
      "slli                t5, t0, 2                      \n\t"
      "add                 %[src00], %[src00], t5         \n\t"
      "add                 %[src01], %[src01], t5         \n\t"
      "add                 %[src02], %[src02], t5         \n\t"
      "add                 %[src10], %[src10], t5         \n\t"
      "add                 %[src12], %[src12], t5         \n\t"
      "add                 %[src20], %[src20], t5         \n\t"
      "add                 %[src21], %[src21], t5         \n\t"
      "add                 %[src22], %[src22], t5         \n\t"
      "vse32.v             v0, (t2)                      \n\t"
      "add                 t2, t2, t5                     \n\t"
      "bnez                t4, LOOPW%=                    \n\t"
      "addi                %[src00], %[src00], 8          \n\t"
      "addi                %[src01], %[src01], 8          \n\t"
      "addi                %[src02], %[src02], 8          \n\t"
      "addi                %[src10], %[src10], 8          \n\t"
      "addi                %[src12], %[src12], 8          \n\t"
      "addi                %[src20], %[src20], 8          \n\t"
      "addi                %[src21], %[src21], 8          \n\t"
      "addi                %[src22], %[src22], 8          \n\t"
      "add                 %[dst], %[dst], t3             \n\t"
      "addi                %[height], %[height], -1       \n\t"
      "bnez                %[height], LOOPH%=             \n\t"
      : [dst] "+r"(dst), [src00] "+r"(src00), [src01] "+r"(src01),
        [src02] "+r"(src02), [src10] "+r"(src10), [src12] "+r"(src12),
        [src20] "+r"(src20), [src21] "+r"(src21), [src22] "+r"(src22),
        [height] "+r"(h_max)
      : [width] "r"(width), [beta] "f"(beta)
      : "cc", "t0", "t1", "t2", "t3", "t4", "t5", "t6");

}

#if 1
int main() {
  const size_t width = 16;
  const size_t height = 16;
  const size_t nsize = width * height;

  using T = float;

  std::vector<T> in = std::move(
      generateRandomNumbers((T)TEST_FP32_MIN, (T)TEST_FP32_MAX, nsize));
  std::vector<float> ref(nsize, 0);
  std::vector<float> out(nsize, 0); 

  image_sobel_c(in.data(), ref.data(), width, height);
  image_sobel_riscv(in.data(), out.data(), width, height);
 
  CheckValue(out.data(), ref.data(), nsize);
  return 0;
}

#else
#include <benchmark/benchmark.h>

#include <functional>
#include <random>

void test_sobel_c(benchmark::State &state) {
  int width = state.range(0);
  int height = state.range(1);
  const size_t nsize = width * height;
  std::vector<float> in(nsize, 1.3);
  std::vector<float> out(nsize, 1.3);

  for (auto _ : state) {
    image_sobel_c(in.data(), out.data(), width, height);
  }
}

#include <vector>
void test_sobel_risc(benchmark::State &state) {
  int width = state.range(0);
  int height = state.range(1);
  const size_t nsize = width * height;
  std::vector<float> in(nsize, 1.3);
  std::vector<float> out(nsize, 1.3);

  for (auto _ : state) {
    image_sobel_riscv(in.data(), out.data(), width, height);
  }
}

static void sobel_cases(benchmark::internal::Benchmark *b) {
  b->Args({8, 256});
  b->Args({8, 512});
  b->Args({8, 1024});
  b->Args({128, 128});
  b->Args({256, 256});
  b->Args({512, 512});
  b->Args({1024, 1024});
}

BENCHMARK(test_sobel_c)->Apply(sobel_cases)->UseRealTime();
BENCHMARK(test_sobel_risc)->Apply(sobel_cases)->UseRealTime();

BENCHMARK_MAIN();

#endif