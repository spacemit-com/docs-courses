#include <bitset>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <math.h>
#include <optional>
#include <random>
#include <riscv_vector.h>
#include <sstream>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#define TEST_FP32_RTOL 1e-2
#define TEST_FP32_ATOL 1e-6
void CheckValue(float *output_value, float *ref_output_value, int len,
                const double rtol = TEST_FP32_RTOL,
                const double atol = TEST_FP32_ATOL) {
  int count = 0;
  bool isok = true;
  for (size_t i = 0; i < len; i++) {
    double ref_data = static_cast<double>(ref_output_value[i]);
    double actual_data = static_cast<double>(output_value[i]);
    if (std::isnan(ref_data)) {
      if (!std::isnan(actual_data))
        std::cout << "value mismatch at index " << i
                  << "; expected is NaN, actual is not NaN" << std::endl;
    } else if (std::isinf(actual_data)) {
      std::cout << "value mismatch at index " << std::endl;
    } else {
      double diff = fabs(ref_data - actual_data);
      if (diff > (atol + fabs(ref_data) * rtol)) {
        std::cout << "value mismatch at index " << i
                  << "; expected: " << ref_data << ", actual: " << actual_data
                  << "  diff:" << diff << "  :"
                  << (atol + fabs(ref_data) * rtol) << "  atol:" << atol
                  << "  fabs(ref_data) * rtol=" << (fabs(ref_data) * rtol)
                  << std::endl;
        if (diff > (atol + fabs(ref_data) * rtol))
          count += 1;
        isok = false;
        if (count > 10)
          return;
      }
    }
  }
  if (isok)
    std::cout << "pass!" << std::endl;
  else
    std::cout << "fail!" << std::endl;
}

void max_data_c(float *src, float *dst, size_t len) {
  float result = src[0];
  for (int ii = 1; ii < len; ii++) {
    if(src[ii] > result)
    result = src[ii];
  }
  *dst = result;
}

void max_data_riscv(float *src, float *dst, size_t len) {
  float result = src[0];
  len -= 1;
  __asm__ volatile(
                   "mv                  t1, %[in]                   \n\t"
                   "mv                  t2, %[dst]                  \n\t" 
                   "vsetvli             t0, zero, e32, m8           \n\t"
                   "vfmv.v.f            v0, %[result]               \n\t"
                   "mv                  t4, %[len]                  \n\t"
                   "LOOPWBODY%=:                                    \n\t"
                   "vsetvli             t0, t4, e32, m8             \n\t"
                   "sub                 t4, t4, t0                  \n\t"
                   "vle32.v             v8, (t1)                    \n\t"
                   "sll                 t5, t0, 2                   \n\t"
                   "add                 t1, t1, t5                  \n\t"
                   "vfmax.vv            v0, v8, v0                  \n\t"
                   "bnez                t4, LOOPWBODY%=             \n\t" 
                   "vfredmax.vs         v16, v0, v0                  \n\t" 
                   "vfmv.f.s            ft1, v16                     \n\t" 
                   "fsw                 ft1, 0(t2)                  \n\t" 
                   :  [dst] "+r"(dst)
                   : [len] "r"(len), [result] "f"(result), [in] "r"(&src[1])
                   : "cc", "t0", "t1", "t2", "t3", "t4", "t5");
}

template <typename T>
std::vector<T> generateRandomNumbers(T min, T max, int64_t length) {
  //   static_assert(std::is_arithmetic<T>::value
  //                 "T must be an arithmetic type ");
  std::random_device rd;
  std::mt19937 gen(rd());
  if constexpr (std::is_integral<T>::value) {
    std::uniform_int_distribution<T> int_dis(min, max);
    std::vector<T> random_numbers(length);
    for (size_t i = 0; i < length; ++i) {
      random_numbers[i] = int_dis(gen);
    }
    return random_numbers;
  } else {
    std::uniform_real_distribution<double> real_dis(static_cast<double>(min),
                                                    static_cast<double>(max));
    std::vector<T> random_numbers(length);
    for (size_t i = 0; i < length; ++i) {
      random_numbers[i] = static_cast<T>(real_dis(gen));
    }
    return random_numbers;
  }
}

#define TEST_FP32_MAX 256.0f
#define TEST_FP32_MIN -256.0f

#if 1
int main() {
  const size_t nsize = 512;

  using T = float;

  std::vector<T> in = std::move(
      generateRandomNumbers((T)TEST_FP32_MIN, (T)TEST_FP32_MAX, nsize));
  std::vector<T> ref = std::move(
      generateRandomNumbers((T)TEST_FP32_MIN, (T)TEST_FP32_MAX, nsize));
  std::vector<T> out(nsize, 0);
  max_data_c(in.data(), ref.data(), nsize);
  max_data_riscv(in.data(), out.data(),nsize);

  CheckValue(out.data(), ref.data(), 1);
  return 0;
}

#else
#include <benchmark/benchmark.h>

#include <functional>
#include <random>

void test_maxdata_c(benchmark::State &state) {
  int nsize = state.range(0);
  std::vector<float> in(nsize, 1.3);
  std::vector<float> out(nsize, 1.3);

  for (auto _ : state) {
    max_data_c(in.data(), out.data(), nsize);
  }
}

#include <vector>
void test_maxdata_risc(benchmark::State &state) {
  int nsize = state.range(0);
  std::vector<float> in(nsize, 1.3);
  std::vector<float> out(nsize, 1.3);

  for (auto _ : state) {
    max_data_riscv(in.data(), out.data(), nsize);
  }
}

static void maxdata_cases(benchmark::internal::Benchmark *b) {
  b->Args({128});
  b->Args({256});
  b->Args({512});
  b->Args({1024});
  b->Args({2048});
  b->Args({4096});
  b->Args({8192}); 
}

BENCHMARK(test_maxdata_c)->Apply(maxdata_cases)->UseRealTime();
BENCHMARK(test_maxdata_risc)->Apply(maxdata_cases)->UseRealTime();

BENCHMARK_MAIN();

#endif