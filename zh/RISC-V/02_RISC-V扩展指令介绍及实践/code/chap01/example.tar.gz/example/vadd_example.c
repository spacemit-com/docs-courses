#include <stdio.h>
#include <sys/time.h>

#define LEN (512)
int a[LEN] = {};
int b[LEN] = {};
int c[LEN] = {};

struct timeval start, end;

int main ()
{
    int length = LEN;

    gettimeofday(&start, NULL);
    for (int m = 0; m < 1000; m++) {
        for (int i = 0; i < length; i++) {
            c[i] = a[i] + b[i];
        }
    }
    gettimeofday(&end, NULL);
    long long int time = (end.tv_sec - start.tv_sec) * 1000000 + end.tv_usec - start.tv_usec;
    printf("the total time is %lld.\n", time);

    return 0;
}
