#include <stdio.h>
#include <sys/time.h>
#include <riscv_vector.h>

#define LEN (512)
int a[LEN] = {};
int b[LEN] = {};
int c[LEN] = {};

struct timeval start, end;

int main ()
{
    int length = LEN;

    gettimeofday(&start, NULL);
    for (int m = 0; m < 1000; m++) {
        int *pa = a;
        int *pb = b;
        int *pc = c;

        asm volatile(
          "mv             t1, %[LENGTH]   \n\t"
          "LOOP:                          \n\t"
          "vsetvli        t0, t1, e32, m4 \n\t"
          "vle32.v        v0, (%[A])      \n\t"
          "sh2add         %[A], t0, %[A]  \n\t"
          "vle32.v        v4, (%[B])      \n\t"
          "sh2add         %[B], t0, %[B]  \n\t"
          "vadd.vv        v8, v0, v4      \n\t"
          "vse32.v        v8, (%[C])      \n\t"
          "sh2add         %[C], t0, %[C]  \n\t"
          "sub            t1, t1, t0      \n\t"
          "bgtz           t1, LOOP        \n\t"
          :[A] "+r" (pa), [B] "+r" (pb), [C] "+r" (pc)
          :[LENGTH] "r"(length)
          :"t0", "t1", "v0", "v1", "v2", "v3", "v4", "v5",
           "v6", "v7", "v8", "v9", "v10", "v11"
          );
    }

    gettimeofday(&end, NULL);
    long long int time = (end.tv_sec - start.tv_sec) * 1000000 + end.tv_usec - start.tv_usec;
    printf("the total time is %lld.\n", time);

    return 0;
}
