#include <stdio.h>
#include <sys/time.h>
#include <riscv_vector.h>

#define LEN (512)
int a[LEN] = {};
int b[LEN] = {};
int c[LEN] = {};

struct timeval start, end;

int main ()
{

    gettimeofday(&start, NULL);
    for (int m = 0; m < 1000; m++) {
        int length = LEN;
        int *pa = a;
        int *pb = b;
        int *pc = c;

        while (length > 0) {
            size_t gvl = __riscv_vsetvl_e32m4(length);
            vint32m4_t v_a = __riscv_vle32_v_i32m4(pa, gvl); // load 8个a数据
            vint32m4_t v_b = __riscv_vle32_v_i32m4(pb, gvl); // load 8个b数据
            vint32m4_t v_c = __riscv_vadd_vv_i32m4(v_a, v_b, gvl); // 向量加法，将8个元素同时相加得到8个c数据
            __riscv_vse32_v_i32m4(pc, v_c, gvl);  // store 8个c数据
            pa += gvl;
            pb += gvl;
            pc += gvl;
            length -= gvl;
        }
    }

    gettimeofday(&end, NULL);
    long long int time = (end.tv_sec - start.tv_sec) * 1000000 + end.tv_usec - start.tv_usec;
    printf("the total time is %lld.\n", time);

    return 0;
}
