#include <linux/module.h>
#include <linux/platform_device.h>

#include <linux/fs.h>
#include <linux/errno.h>
#include <linux/miscdevice.h>
#include <linux/kernel.h>
#include <linux/major.h>
#include <linux/mutex.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/stat.h>
#include <linux/init.h>
#include <linux/device.h>
#include <linux/tty.h>
#include <linux/kmod.h>
#include <linux/gfp.h>
#include <linux/gpio/consumer.h>
#include <linux/of.h>


/* 1. 确定主设备号                                                                 */
static int major = 0;
static struct class *test_class;
static struct gpio_desc *test_gpio;


/* 3. 实现对应的open/read/write等函数，填入file_operations结构�?                  */
static ssize_t test_drv_read (struct file *file, char __user *buf, size_t size, loff_t *offset)
{
	printk("%s %s line %d\n", __FILE__, __FUNCTION__, __LINE__);
	return 0;
}

/* write(fd, &val, 1); */
static ssize_t test_drv_write (struct file *file, const char __user *buf, size_t size, loff_t *offset)
{
	int err;
	char status;
	printk("%s %s line %d\n", __FILE__, __FUNCTION__, __LINE__);
	err = copy_from_user(&status, buf, 1);

	/* 根据次设备号和status控制LED */
	gpiod_set_value(test_gpio, status);

	return 1;
}

static int test_drv_open (struct inode *node, struct file *file)
{
	printk("%s %s line %d\n", __FILE__, __FUNCTION__, __LINE__);
	/* 根据次设备号初始化LED */
	gpiod_direction_output(test_gpio, 0);

	return 0;
}

static int test_drv_close (struct inode *node, struct file *file)
{
	printk("%s %s line %d\n", __FILE__, __FUNCTION__, __LINE__);
	return 0;
}

/* 定义自己的file_operations结构�?                                             */
static struct file_operations test_drv = {
	.owner	 = THIS_MODULE,
	.open    = test_drv_open,
	.read    = test_drv_read,
	.write   = test_drv_write,
	.release = test_drv_close,
};

/* 4. 从platform_device获得GPIO
 *    把file_operations结构体告诉内核：注册驱动程序
 */
static int chip_demo_gpio_probe(struct platform_device *pdev)
{
	printk("%s %s line %d\n", __FILE__, __FUNCTION__, __LINE__);

	/* 4.1 设备树中定义�? led-gpios=<...>;	*/
    test_gpio = gpiod_get(&pdev->dev, NULL, 0);
	if (IS_ERR(test_gpio)) {
		dev_err(&pdev->dev, "Failed to get GPIO for test\n");
		return PTR_ERR(test_gpio);
	}

	/* 4.2 注册file_operations 	*/
	major = register_chrdev(0, "bianbu_gpio_test", &test_drv);  /* /dev/led */

	test_class = class_create("bianbu_gpio_test_class");
	if (IS_ERR(test_class)) {
		printk("%s %s line %d\n", __FILE__, __FUNCTION__, __LINE__);
		unregister_chrdev(major, "bianbu_gpio_test");
		gpiod_put(test_gpio);
		return PTR_ERR(test_class);
	}

	device_create(test_class, NULL, MKDEV(major, 0), NULL, "bianbu_gpio_test%d", 0); /* /dev/bianbu_gpio_test0 */

    return 0;

}

static int chip_demo_gpio_remove(struct platform_device *pdev)
{
	device_destroy(test_class, MKDEV(major, 0));
	class_destroy(test_class);
	unregister_chrdev(major, "bianbu_gpio_test");
	gpiod_put(test_gpio);

    return 0;
}


static const struct of_device_id bianbu_pinctrl[] = {
    { .compatible = "bianbu,gpio-test" },
    { },
};

/* 1. 定义platform_driver */
static struct platform_driver chip_demo_gpio_driver = {
    .probe      = chip_demo_gpio_probe,
    .remove     = chip_demo_gpio_remove,
    .driver     = {
        .name   = "bianbu_gpio_test",
        .of_match_table = bianbu_pinctrl,
    },
};

/* 2. 在入口函数注册platform_driver */
static int __init test_init(void)
{
    int err;

	printk("%s %s line %d\n", __FILE__, __FUNCTION__, __LINE__);

    err = platform_driver_register(&chip_demo_gpio_driver);

	return err;
}

/* 3. 有入口函数就应该有出口函数：卸载驱动程序时，就会去调用这个出口函数 *     卸载platform_driver
 */
static void __exit test_exit(void)
{
	printk("%s %s line %d\n", __FILE__, __FUNCTION__, __LINE__);

    platform_driver_unregister(&chip_demo_gpio_driver);
}


/* 7. 其他完善：提供设备信息，自动创建设备节点                                     */

module_init(test_init);
module_exit(test_exit);

MODULE_LICENSE("GPL");


