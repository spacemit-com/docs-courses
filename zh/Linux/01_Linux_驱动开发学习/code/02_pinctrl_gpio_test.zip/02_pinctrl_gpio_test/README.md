# GPIO驱动测试项目

## 项目简介

这是一个Linux内核GPIO驱动测试项目，实现了一个简单的GPIO控制驱动程序及其对应的用户空间测试程序。该项目演示了如何在Linux内核中编写一个平台驱动程序来控制GPIO引脚。

## 文件说明

### 1. gpiodrv.c - GPIO内核驱动模块

这是项目的核心文件，包含了完整的Linux内核GPIO驱动程序代码。

**主要功能：**
- 实现了一个基于platform_driver的GPIO驱动程序
- 通过设备树获取GPIO资源
- 创建字符设备节点 `/dev/bianbu_gpio_test0`
- 提供标准的文件操作接口（open, read, write, close）

**关键特性：**
- **设备树兼容性：** 支持`compatible = "bianbu,gpio-test"`的设备树节点
- **GPIO控制：** 通过gpiod接口控制GPIO引脚的高低电平
- **字符设备：** 注册为字符设备，用户空间可通过文件操作接口访问
- **自动设备节点创建：** 使用class_create和device_create自动创建设备节点

**驱动操作流程：**
1. 模块加载时注册platform_driver
2. 设备树匹配成功后调用probe函数
3. 从设备树获取GPIO资源
4. 注册字符设备驱动
5. 创建设备类和设备节点
6. 用户空间可通过写入数据控制GPIO状态

### 2. gpiotest.c - 用户空间测试程序

这是一个简单的C语言用户空间应用程序，用于测试GPIO驱动的功能。

**主要功能：**
- 打开GPIO设备文件
- 通过写入操作控制GPIO引脚状态
- 支持设置GPIO为高电平或低电平

**使用方法：**
```bash
# 设置GPIO为高电平
./gpiotest /dev/bianbu_gpio_test0 high

# 设置GPIO为低电平  
./gpiotest /dev/bianbu_gpio_test0 low
```

**程序逻辑：**
1. 检查命令行参数（设备文件路径和状态）
2. 打开指定的设备文件
3. 根据参数写入1（高电平）或0（低电平）
4. 关闭设备文件

### 3. Makefile - 编译配置文件

这是项目的编译配置文件，支持同时编译内核模块和用户空间程序。

**编译目标：**
- **内核模块编译：** 将`gpiodrv.c`编译成`gpiodrv.ko`内核模块
- **用户程序编译：** 将`gpiotest.c`编译成可执行文件`gpiotest`

**重要配置：**
- `KERN_DIR`: 指定Linux内核源码路径
- `CROSS_COMPILE`: 交叉编译工具链前缀
- `obj-m += gpiodrv.o`: 指定要编译的内核模块
