#include <linux/module.h>

#include <linux/fs.h>
#include <linux/errno.h>
#include <linux/miscdevice.h>
#include <linux/kernel.h>
#include <linux/major.h>
#include <linux/mutex.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/stat.h>
#include <linux/init.h>
#include <linux/device.h>
#include <linux/tty.h>
#include <linux/kmod.h>
#include <linux/gfp.h>
#include <linux/gpio/consumer.h>
#include <linux/gpio/driver.h>
#include <linux/platform_device.h>
#include <linux/of_irq.h>
#include <linux/interrupt.h>
#include <linux/irq.h>
#include <linux/slab.h>


// gpio_key 结构体：描述一个按键的GPIO、中断号、按键码和标签
struct gpio_key{
	struct gpio_desc *gpiod; // GPIO描述符
	int irq;                 // 中断号
	int code;                // 按键码
	char label[32];          // 按键标签
};

// 只支持一个外部按键
static struct gpio_key gpio_key;

// 主设备号
static int major = 0;
// 设备类指针，用于自动创建设备节点
static struct class *gpio_key_class;
// 保存最近一次按键事件的值
static int g_key = 0;
// 等待队列，用于阻塞/唤醒用户空间读取
static DECLARE_WAIT_QUEUE_HEAD(gpio_key_wait);

/*
 * 用户空间read操作实现：
 * 阻塞等待有按键事件发生，返回按键值
 */
static ssize_t gpio_key_drv_read (struct file *file, char __user *buf, size_t size, loff_t *offset)
{
	int err;
	// 阻塞直到有按键事件（g_key非0）
	wait_event_interruptible(gpio_key_wait, g_key);
	// 将按键值拷贝到用户空间
	err = copy_to_user(buf, &g_key, 4);
	// 读完后清零
	g_key = 0;
	return 4;
}

// file_operations结构体，只实现了read
static struct file_operations gpio_key_drv = {
	.owner   = THIS_MODULE,
	.read    = gpio_key_drv_read,
};

/*
 * 按键中断服务函数：
 * 读取GPIO电平，组合按键码和电平，唤醒等待队列
 */
static irqreturn_t gpio_key_isr(int irq, void *dev_id)
{
	struct gpio_key *key = dev_id;
	int val = gpiod_get_value(key->gpiod);
	// 打印调试信息
	printk("key %s(code=%d) %d\n", key->label, key->code, val);
	// 组合按键码和电平
	g_key = (key->code << 8) | val;
	// 唤醒等待队列
	wake_up_interruptible(&gpio_key_wait);
	return IRQ_HANDLED;
}

/*
 * probe函数：
 * 1. 获取设备树第一个子节点，获取GPIO和中断号
 * 2. 注册中断
 * 3. 注册字符设备，创建设备节点
 */
static int gpio_key_probe(struct platform_device *pdev)
{
	int err;
	struct device_node *node = pdev->dev.of_node;
	const char *label;

	// 只处理第一个子节点或主节点
	struct device_node *child = of_get_next_child(node, NULL);
	if (!child) {
		printk("%s %s line %d, no key child node available\n", __FILE__, __FUNCTION__, __LINE__);
		return -1;
	}

	// 获取GPIO描述符
	struct fwnode_handle *fwnode = of_fwnode_handle(child);
	gpio_key.gpiod = fwnode_gpiod_get_index(fwnode, NULL, 0, GPIOD_IN, gpio_key.label);

	if (IS_ERR(gpio_key.gpiod) || !gpio_key.gpiod) {
		printk("%s %s line %d, devm_gpiod_get_optional fail\n", __FILE__, __FUNCTION__, __LINE__);
		return -1;
	}

	// 获取中断号
	gpio_key.irq = gpiod_to_irq(gpio_key.gpiod);
	// 获取label属性
	if (!of_property_read_string(child, "label", &label)) {
		strncpy(gpio_key.label, label, sizeof(gpio_key.label)-1);
	} else {
		snprintf(gpio_key.label, sizeof(gpio_key.label), "key0");
	}

	// 获取linux,code属性
	if (of_property_read_u32(child, "linux,code", &gpio_key.code)) {
		gpio_key.code = 0;
	}

	// 注册中断，双沿触发
	err = request_irq(gpio_key.irq, gpio_key_isr, IRQF_TRIGGER_RISING | IRQF_TRIGGER_FALLING, gpio_key.label, &gpio_key);
	if (err) {
		printk("request_irq failed for %s\n", gpio_key.label);
		return err;
	}

	// 注册字符设备
	major = register_chrdev(0, "key_irq_test", &gpio_key_drv);  /* /dev/key_irq_test */
	// 创建设备类和设备节点
	gpio_key_class = class_create("key_irq_test_class");
	if (IS_ERR(gpio_key_class)) {
		printk("%s %s line %d\n", __FILE__, __FUNCTION__, __LINE__);
		unregister_chrdev(major, "key_irq_test");
		free_irq(gpio_key.irq, &gpio_key);
		return PTR_ERR(gpio_key_class);
	}

	device_create(gpio_key_class, NULL, MKDEV(major, 0), NULL, "key_irq_test"); /* /dev/key_irq_test */
	return 0;
}

/*
 * remove函数：
 * 注销字符设备、销毁设备节点和类，释放中断
 */
static int gpio_key_remove(struct platform_device *pdev)
{
	device_destroy(gpio_key_class, MKDEV(major, 0));
	class_destroy(gpio_key_class);
	unregister_chrdev(major, "key_irq_test");
	free_irq(gpio_key.irq, &gpio_key);
	return 0;
}

// 设备树匹配表
static const struct of_device_id key_irq_of_match[] = {
    { .compatible = "my-gpio-keys" },
    { },
};

// platform_driver结构体，指定probe/remove
static struct platform_driver gpio_keys_driver = {
    .probe      = gpio_key_probe,
    .remove     = gpio_key_remove,
    .driver     = {
        .name   = "key_irq_test",
        .of_match_table = key_irq_of_match,
    },
};

/*
 * 模块入口函数：注册platform_driver
 */
static int __init gpio_key_init(void)
{
    int err;
	printk("%s %s line %d\n", __FILE__, __FUNCTION__, __LINE__);
    err = platform_driver_register(&gpio_keys_driver);
	return err;
}

/*
 * 模块出口函数：注销platform_driver
 */
static void __exit gpio_key_exit(void)
{
	printk("%s %s line %d\n", __FILE__, __FUNCTION__, __LINE__);
    platform_driver_unregister(&gpio_keys_driver);
}

// 指定模块加载/卸载函数
module_init(gpio_key_init);
module_exit(gpio_key_exit);

MODULE_LICENSE("GPL");


