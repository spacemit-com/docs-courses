#ifndef __SPI_OLED_IOCTL_H__
#define __SPI_OLED_IOCTL_H__

#define SPI_OLED_IOC_MAGIC 'O'
#define SPI_OLED_SET_DC_HIGH    _IO(SPI_OLED_IOC_MAGIC, 1)
#define SPI_OLED_SET_DC_LOW     _IO(SPI_OLED_IOC_MAGIC, 2)
#define SPI_OLED_WRITE_CMD      _IOW(SPI_OLED_IOC_MAGIC, 3, unsigned char)
#define SPI_OLED_WRITE_DATA     _IOW(SPI_OLED_IOC_MAGIC, 4, unsigned char*)

#endif // __SPI_OLED_IOCTL_H__
