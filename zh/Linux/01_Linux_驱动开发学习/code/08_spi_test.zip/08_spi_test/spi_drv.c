#include <linux/module.h>
#include <linux/init.h>
#include <linux/spi/spi.h>
#include <linux/gpio.h>
#include <linux/of_gpio.h>
#include <linux/delay.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include "spi_oled_ioctl.h"

#define DEVICE_NAME "spi_oled"
#define CLASS_NAME "spi_oled"

struct spi_oled_dev {
    struct spi_device *spi;
    struct cdev cdev;
    struct device *device;
    struct class *class;
    dev_t devt;
    int dc_gpio;
    struct mutex lock;
};

static struct spi_oled_dev *spi_oled;

// 字符设备操作函数
static int spi_oled_open(struct inode *inode, struct file *file)
{
    file->private_data = spi_oled;
    return 0;
}

static int spi_oled_release(struct inode *inode, struct file *file)
{
    return 0;
}

static long spi_oled_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    struct spi_oled_dev *dev = file->private_data;
    int ret = 0;
    u8 data;
    
    switch (cmd) {
    case SPI_OLED_SET_DC_HIGH:
        dev_dbg(&dev->spi->dev, "Setting DC HIGH\n");
        gpio_set_value(dev->dc_gpio, 1);
        break;
        
    case SPI_OLED_SET_DC_LOW:
        dev_dbg(&dev->spi->dev, "Setting DC LOW\n");
        gpio_set_value(dev->dc_gpio, 0);
        break;
        
    case SPI_OLED_WRITE_CMD:
        if (copy_from_user(&data, (void __user *)arg, 1))
            return -EFAULT;
        
        dev_dbg(&dev->spi->dev, "Writing command: 0x%02X\n", data);
        mutex_lock(&dev->lock);
        gpio_set_value(dev->dc_gpio, 0);  // DC=0 for command
        udelay(10);
        ret = spi_write(dev->spi, &data, 1);
        mutex_unlock(&dev->lock);
        break;
        
    case SPI_OLED_WRITE_DATA:
        if (copy_from_user(&data, (void __user *)arg, 1))
            return -EFAULT;
        
        dev_dbg(&dev->spi->dev, "Writing data: 0x%02X\n", data);
        mutex_lock(&dev->lock);
        gpio_set_value(dev->dc_gpio, 1);  // DC=1 for data
        udelay(10);
        ret = spi_write(dev->spi, &data, 1);
        mutex_unlock(&dev->lock);
        break;
        
    default:
        return -ENOTTY;
    }
    
    return ret;
}

static ssize_t spi_oled_write(struct file *file, const char __user *buf,
                             size_t count, loff_t *ppos)
{
    struct spi_oled_dev *dev = file->private_data;
    u8 *data;
    int ret;
    
    if (count > 4096)  // 限制最大写入大小
        return -EINVAL;
    
    data = kmalloc(count, GFP_KERNEL);
    if (!data)
        return -ENOMEM;
    
    if (copy_from_user(data, buf, count)) {
        kfree(data);
        return -EFAULT;
    }
    
    dev_dbg(&dev->spi->dev, "Writing %zu bytes of data\n", count);
    mutex_lock(&dev->lock);
    ret = spi_write(dev->spi, data, count);
    mutex_unlock(&dev->lock);
    
    kfree(data);
    return ret < 0 ? ret : count;
}

static const struct file_operations spi_oled_fops = {
    .owner = THIS_MODULE,
    .open = spi_oled_open,
    .release = spi_oled_release,
    .write = spi_oled_write,
    .unlocked_ioctl = spi_oled_ioctl,
};

// SPI驱动probe函数
static int spi_oled_probe(struct spi_device *spi)
{
    struct spi_oled_dev *dev;
    int ret;
    
    dev_info(&spi->dev, "SPI OLED probe start\n");
    
    dev = devm_kzalloc(&spi->dev, sizeof(*dev), GFP_KERNEL);
    if (!dev)
        return -ENOMEM;
    
    dev->spi = spi;
    spi_set_drvdata(spi, dev);
    spi_oled = dev;
    
    // 获取DC GPIO
    dev->dc_gpio = of_get_named_gpio(spi->dev.of_node, "dc-gpios", 0);
    if (!gpio_is_valid(dev->dc_gpio)) {
        dev_err(&spi->dev, "Failed to get DC GPIO\n");
        return -EINVAL;
    }
    
    ret = devm_gpio_request_one(&spi->dev, dev->dc_gpio, 
                               GPIOF_OUT_INIT_LOW, "spi-oled-dc");
    if (ret) {
        dev_err(&spi->dev, "Failed to request DC GPIO: %d\n", ret);
        return ret;
    }
    
    // 配置SPI
    spi->mode = SPI_MODE_0;
    spi->bits_per_word = 8;
    // spi->max_speed_hz = 500000; // 降低到500kHz，提升兼容性
    ret = spi_setup(spi);
    if (ret) {
        dev_err(&spi->dev, "SPI setup failed: %d\n", ret);
        return ret;
    }
    
    mutex_init(&dev->lock);
    
    // 创建字符设备
    ret = alloc_chrdev_region(&dev->devt, 0, 1, DEVICE_NAME);
    if (ret) {
        dev_err(&spi->dev, "Failed to allocate chrdev region: %d\n", ret);
        return ret;
    }
    
    cdev_init(&dev->cdev, &spi_oled_fops);
    dev->cdev.owner = THIS_MODULE;
    
    ret = cdev_add(&dev->cdev, dev->devt, 1);
    if (ret) {
        dev_err(&spi->dev, "Failed to add cdev: %d\n", ret);
        unregister_chrdev_region(dev->devt, 1);
        return ret;
    }
    
    // 创建设备类
    dev->class = class_create(CLASS_NAME);
    if (IS_ERR(dev->class)) {
        ret = PTR_ERR(dev->class);
        cdev_del(&dev->cdev);
        unregister_chrdev_region(dev->devt, 1);
        return ret;
    }
    
    // 创建设备节点
    dev->device = device_create(dev->class, &spi->dev, dev->devt, 
                               NULL, DEVICE_NAME);
    if (IS_ERR(dev->device)) {
        ret = PTR_ERR(dev->device);
        class_destroy(dev->class);
        cdev_del(&dev->cdev);
        unregister_chrdev_region(dev->devt, 1);
        return ret;
    }
    
    dev_info(&spi->dev, "SPI OLED driver probed successfully\n");
    return 0;
}

static void spi_oled_remove(struct spi_device *spi)
{
    struct spi_oled_dev *dev = spi_get_drvdata(spi);
    
    device_destroy(dev->class, dev->devt);
    class_destroy(dev->class);
    cdev_del(&dev->cdev);
    unregister_chrdev_region(dev->devt, 1);
    
    dev_info(&spi->dev, "SPI OLED driver removed\n");
}

static const struct of_device_id spi_oled_of_match[] = {
    { .compatible = "ssd1106,oled", },  // 改为 SSD1106
    { }
};
MODULE_DEVICE_TABLE(of, spi_oled_of_match);

static struct spi_driver spi_oled_driver = {
    .driver = {
        .name = "spi-oled",
        .of_match_table = spi_oled_of_match,
    },
    .probe = spi_oled_probe,
    .remove = spi_oled_remove,
};

module_spi_driver(spi_oled_driver);

MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("Generic SPI OLED Driver");
MODULE_LICENSE("GPL");
