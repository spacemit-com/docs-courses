#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include "spi_oled_ioctl.h"
#include "ssd1106_cmd.h"

static int fd;

// 发送命令到SSD1106，去除重试和延时
int ssd1106_send_command(unsigned char cmd)
{
    int ret;
    ret = ioctl(fd, SPI_OLED_WRITE_CMD, &cmd);
    printf("Send command: 0x%02X, ret=%d\n", cmd, ret);
    return ret;
}

// 发送数据到SSD1106，添加调试信息
int ssd1106_send_data(unsigned char data)
{
    int ret;
    ret = ioctl(fd, SPI_OLED_WRITE_DATA, &data);
    printf("Send data: 0x%02X, ret=%d\n", data, ret);
    return ret;
}

// 发送数据缓冲区
int ssd1106_send_data_buffer(unsigned char *data, int len)
{
    int ret;

    // 设置DC为高（数据模式）
    printf("Setting DC HIGH for data\n");
    ret = ioctl(fd, SPI_OLED_SET_DC_HIGH);
    if (ret < 0) {
        perror("Failed to set DC high");
        return ret;
    }

    usleep(1000);  // 等待DC稳定

    // 写入数据
    printf("Writing %d bytes of data\n", len);
    ret = write(fd, data, len);
    if (ret < 0) {
        perror("Failed to write data buffer");
        return ret;
    }

    return ret;
}

// 设置显示位置（使用页寻址模式）
int ssd1106_set_position(unsigned char page, unsigned char column)
{
    printf("Setting position: page=%d, column=%d\n", page, column);
    if (ssd1106_send_command(0xB0 | (page & 0x0F)) < 0) return -1;  // 设置页地址
    if (ssd1106_send_command(0x00 | (column & 0x0F)) < 0) return -1;  // 设置列地址低4位
    if (ssd1106_send_command(0x10 | ((column >> 4) & 0x0F)) < 0) return -1;  // 设置列地址高4位
    return 0;
}

// 清屏
int ssd1106_clear_screen(void)
{
    printf("Clearing screen...\n");
    unsigned char clear_data[128];
    memset(clear_data, 0x00, sizeof(clear_data));

    // SSD1106需要分页清屏
    for (int page = 0; page < 8; page++) {
        ssd1106_set_position(page, 0);
        if (ssd1106_send_data_buffer(clear_data, sizeof(clear_data)) < 0) {
            return -1;
        }
    }
    return 0;
}

// 初始化SSD1106 OLED，使用更详细的初始化序列
int ssd1106_init(void)
{
    printf("Starting SSD1106 OLED initialization...\n");

    // 基础初始化序列
    ssd1106_send_command(0xAE);    // 关闭显示

    ssd1106_send_command(0xD5);    // 设置时钟分频因子、振荡器频率
    ssd1106_send_command(0x50);    // 建议值为0x50

    ssd1106_send_command(0x20);    // 设置内存寻址模式
    ssd1106_send_command(0x02);    // 页寻址模式

    ssd1106_send_command(0xA8);    // 设置多路复用率
    ssd1106_send_command(0x3F);    // 63

    ssd1106_send_command(0xD3);    // 设置显示偏移
    ssd1106_send_command(0x00);    // 无偏移

    ssd1106_send_command(0x40);    // 设置显示开始行为第一行

    ssd1106_send_command(0xA1);    // 段重映射，A1正常（从左到右），A0反转

    ssd1106_send_command(0xC8);    // COM引脚扫描方向，C8正常（从上到下），C0反转

    ssd1106_send_command(0xDA);    // 设置COM引脚硬件配置
    ssd1106_send_command(0x12);

    ssd1106_send_command(0x81);    // 设置对比度
    ssd1106_send_command(0xCF);    // 更高的对比度值

    ssd1106_send_command(0xD9);    // 设置预充电周期
    ssd1106_send_command(0xF1);    //

    ssd1106_send_command(0xDB);    // 设置VCOMH
    ssd1106_send_command(0x30);    // 0.83*VCC

    ssd1106_send_command(0xA4);    // 全局显示开启，正常显示

    ssd1106_send_command(0xA6);    // 设置正常显示（非反显）

    ssd1106_send_command(0x8D);    // 设置充电泵
    ssd1106_send_command(0x14);    // 开启充电泵

    ssd1106_clear_screen();        // 清屏

    ssd1106_send_command(0xAF);    // 开启显示

    printf("SSD1106 OLED initialization completed\n");
    return 0;
}


// 8x16 ASCII字模（只包含用到的字符）
static const unsigned char font8x16[][16] = {
    // ' '
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    // 'A'
    {0x00,0x00,0x3C,0x42,0x42,0x7E,0x42,0x42,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    // 'B'
    {0x00,0x00,0x7C,0x42,0x7C,0x42,0x42,0x7C,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    // 'C'
    {0x00,0x00,0x3C,0x42,0x40,0x40,0x42,0x3C,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
};

// 字符映射表
static int font8x16_index(char ch) {
    switch(ch) {
        case ' ': return 0;
        case 'A': return 1;
        case 'B': return 2;
        case 'C': return 3;
        default: return 0; // 未知字符显示为空格
    }
}

// 在OLED显示字符串，从顶部开始显示
void ssd1106_show_string(const char *str)
{
    unsigned char buf[128] = {0};
    int i, j, k, idx;
    int len = strlen(str);
    if (len > 16) len = 16; // 最多显示16个8x8字符

    // 显示上半部分（page 0）
    ssd1106_set_position(0, 0);
    memset(buf, 0, sizeof(buf));
    
    // 每个字符占用8列
    for (i = 0; i < len; i++) {
        idx = font8x16_index(str[i]);
        // 对于每一列
        for (j = 0; j < 8; j++) {
            unsigned char col = 0;
            // 构建这一列的8个像素
            for (k = 0; k < 8; k++) {
                if (font8x16[idx][k] & (1 << (7-j))) {
                    col |= (1 << k);
                }
            }
            buf[i*8 + j] = col;
        }
    }
    ssd1106_send_data_buffer(buf, 128);

    // 显示下半部分（page 1）
    ssd1106_set_position(1, 0);
    memset(buf, 0, sizeof(buf));
    
    // 每个字符占用8列
    for (i = 0; i < len; i++) {
        idx = font8x16_index(str[i]);
        // 对于每一列
        for (j = 0; j < 8; j++) {
            unsigned char col = 0;
            // 构建这一列的8个像素
            for (k = 0; k < 8; k++) {
                if (font8x16[idx][k+8] & (1 << (7-j))) {
                    col |= (1 << k);
                }
            }
            buf[i*8 + j] = col;
        }
    }
    ssd1106_send_data_buffer(buf, 128);
}



int main(int argc, char *argv[])
{
    int ret;
    const char *device_path;

    printf("SSD1106 OLED Test Program\n");

    if (argc != 2) {
        printf("Usage: %s /dev/spi_oled\n", argv[0]);
        return -1;
    }
    device_path = argv[1];

    printf("Opening device: %s\n", device_path);
    fd = open(device_path, O_RDWR);
    if (fd < 0) {
        perror("Failed to open device");
        return -1;
    }

    // 初始化OLED
    if (ssd1106_init() < 0) {
        printf("Failed to initialize OLED\n");
        close(fd);
        return -1;
    }

    sleep(1);

    // 清屏
    printf("Clearing screen...\n");
    ssd1106_clear_screen();
    sleep(1);

    // 显示文字
    printf("Displaying ABC...\n");
    ssd1106_show_string("  ABC");  // 在ABC前添加两个空格以调整位置
    printf("Display command sent. Press Enter to exit...\n");
    getchar();

    // 清屏并关闭显示
    printf("Cleaning up...\n");
    ssd1106_clear_screen();
    ssd1106_send_command(SSD1106_DISPLAY_OFF);
    close(fd);
    return 0;
}
