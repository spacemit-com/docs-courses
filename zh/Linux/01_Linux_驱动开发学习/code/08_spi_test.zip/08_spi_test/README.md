# SPI OLED驱动测试项目

## 项目简介

这是一个Linux内核SPI OLED驱动测试项目，实现了一个用于控制SSD1106 OLED显示屏的SPI驱动程序及其对应的用户空间测试程序。该项目演示了如何在Linux内核中编写一个SPI驱动程序来控制OLED显示设备。

## 文件说明

### 1. spi_drv.c - SPI内核驱动模块
这是项目的核心文件，包含了完整的Linux内核SPI驱动程序代码。

**主要功能：**
- 实现了一个基于SPI的OLED显示驱动程序
- 通过设备树获取SPI和GPIO资源
- 创建字符设备节点 `/dev/spi_oled`
- 提供ioctl接口用于控制OLED显示
- 支持DC（数据/命令）控制引脚

**关键特性：**
- **SPI通信**: 使用Linux SPI框架进行底层通信
- **GPIO控制**: 通过GPIO控制OLED的DC引脚（数据/命令切换）
- **字符设备**: 注册为字符设备，提供ioctl接口
- **设备树兼容**: 支持设备树配置
- **多种操作模式**: 支持命令模式和数据模式切换

### 2. spi_test.c - 用户空间测试程序
这是一个功能完整的C语言用户空间应用程序，用于测试SPI OLED驱动的功能。

**主要功能：**
- SSD1106 OLED显示屏初始化
- 屏幕清除功能
- 字符串显示功能
- 完整的OLED控制接口封装

**核心函数：**
- `ssd1106_init()`: 初始化OLED显示屏
- `ssd1106_send_command()`: 发送命令到OLED
- `ssd1106_send_data()`: 发送数据到OLED
- `ssd1106_clear_screen()`: 清除屏幕
- `ssd1106_show_string()`: 显示字符串
- `ssd1106_set_position()`: 设置显示位置

**显示特性：**
- 支持8x16字体显示
- 页寻址模式
- 支持基本ASCII字符显示
- 可调整显示位置和对比度

### 3. spi_oled_ioctl.h - IOCTL命令定义
定义了用户空间与内核驱动通信的ioctl命令。

**支持的ioctl命令：**
- `SPI_OLED_SET_DC_HIGH`: 设置DC引脚为高电平（数据模式）
- `SPI_OLED_SET_DC_LOW`: 设置DC引脚为低电平（命令模式）
- `SPI_OLED_WRITE_CMD`: 写入命令
- `SPI_OLED_WRITE_DATA`: 写入数据

### 4. ssd1106_cmd.h - SSD1106命令定义
包含了SSD1106 OLED控制器的完整命令集定义。

**主要命令分类：**
- 基础控制命令（开关显示、设置对比度等）
- 寻址模式命令（页寻址、列寻址等）
- 硬件配置命令（时钟、复用、引脚配置等）
- 显示控制命令（正常/反显、全局显示等）

### 5. Makefile - 编译配置文件
支持同时编译内核模块和用户空间程序的编译配置文件。

**编译目标：**
- **内核模块编译**: 将`spi_drv.c`编译成`spi_drv.ko`内核模块
- **用户程序编译**: 将`spi_test.c`编译成可执行文件`spi_test`

**重要配置：**
- `KERN_DIR`: 指定Linux内核源码路径
- `CROSS_COMPILE`: 交叉编译工具链前缀
- `obj-m += spi_drv.o`: 指定要编译的内核模块