#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <stdlib.h>

/* TOF 协议定义 */
#define TOF_FRAME_HEADER        0x57
#define TOF_FUNCTION_MARK       0x00
#define TOF_FRAME_SIZE          16
#define TOF_RESERVED_BYTE       0xFF  /* 第3个字节是保留字段，值为0xFF */

/* TOF 数据结构 - 解析后的数据 */
struct tof_data {
    uint8_t  module_id;          /* 模块ID (byte 3) */
    uint32_t system_time;        /* 系统时间，毫秒 (bytes 4-7, 小端) */
    uint32_t distance_mm;        /* 距离，毫米 (bytes 8-10, 小端, 3字节) */
    uint8_t  status;             /* 距离状态 (byte 11) */
    uint16_t signal_strength;    /* 信号强度 (bytes 12-13, 小端) */
    uint8_t  precision;          /* 测距精度，厘米 (byte 14) */
};

/* 重新同步命令 */
static uint8_t tof_resync_cmd[8] = {0x57, 0x10, 0xFF, 0xFF, 0x00, 0xFF, 0xFF, 0x63};

void print_usage(const char *prog)
{
    printf("Usage:\n");
    printf("  %s /dev/ttyS10                 # Read distance data (default mode)\n", prog);
}

/* 计算校验和 */
uint8_t calculate_checksum(const uint8_t *data, int len)
{
    uint8_t sum = 0;
    for (int i = 0; i < len; i++) {
        sum += data[i];
    }
    return sum;
}

/* 解析TOF帧 */
int parse_tof_frame(const uint8_t *frame, struct tof_data *data)
{
    /* 验证帧头 */
    if (frame[0] != TOF_FRAME_HEADER) {
        printf("Invalid header: 0x%02x (expected 0x%02x)\n", frame[0], TOF_FRAME_HEADER);
        return -1;
    }

    /* 验证功能标识 */
    if (frame[1] != TOF_FUNCTION_MARK) {
        printf("Invalid function mark: 0x%02x (expected 0x%02x)\n", frame[1], TOF_FUNCTION_MARK);
        return -1;
    }

    /* 验证保留字节 */
    if (frame[2] != TOF_RESERVED_BYTE) {
        printf("Invalid reserved byte: 0x%02x (expected 0x%02x)\n", frame[2], TOF_RESERVED_BYTE);
        return -1;
    }

    /* 分析实际的帧格式 */
    printf("Frame analysis:\n");
    printf("  Header: 0x%02x, Function: 0x%02x, Reserved: 0x%02x, ID: 0x%02x\n", 
           frame[0], frame[1], frame[2], frame[3]);
    printf("  Time bytes: %02x %02x %02x %02x (little-endian: %u ms)\n",
           frame[4], frame[5], frame[6], frame[7],
           frame[4] | (frame[5] << 8) | (frame[6] << 16) | (frame[7] << 24));
    printf("  Distance bytes: %02x %02x %02x (little-endian: %u mm)\n",
           frame[8], frame[9], frame[10],
           frame[8] | (frame[9] << 8) | (frame[10] << 16));
    printf("  Status: 0x%02x\n", frame[11]);
    printf("  Signal bytes: %02x %02x (little-endian: %u)\n",
           frame[12], frame[13], frame[12] | (frame[13] << 8));
    printf("  Precision: 0x%02x\n", frame[14]);
    printf("  Checksum: 0x%02x\n", frame[15]);

    /* 验证校验和 - 计算前15字节的和 */
    uint8_t calculated_checksum = calculate_checksum(frame, 15);
    printf("  Calculated checksum: 0x%02x\n", calculated_checksum);

    if (calculated_checksum != frame[15]) {
        printf("Checksum mismatch: calculated=0x%02x, received=0x%02x\n", 
               calculated_checksum, frame[15]);
    }

    /* 提取数据 - 按照实际格式 */
    data->module_id = frame[3];  /* 模块ID在第4个字节 */

    /* 系统时间 (小端模式, 4字节) */
    data->system_time = frame[4] | (frame[5] << 8) | (frame[6] << 16) | (frame[7] << 24);

    /* 距离 (小端模式, 3字节) */
    data->distance_mm = frame[8] | (frame[9] << 8) | (frame[10] << 16);

    data->status = frame[11];

    /* 信号强度 (小端模式, 2字节) */
    data->signal_strength = frame[12] | (frame[13] << 8);

    data->precision = frame[14];

    return 0;
}

/* 显示原始十六进制数据 */
void show_raw_data(const uint8_t *data, int len)
{
    printf("Raw data (%d bytes): ", len);
    for (int i = 0; i < len; i++) {
        printf("%02x ", data[i]);
        if ((i + 1) % 16 == 0) {
            printf("\n                     ");
        }
    }
    printf("\n");
}

/* 寻找帧头 */
int find_frame_start(const uint8_t *buffer, int len)
{
    for (int i = 0; i < len - 1; i++) {
        if (buffer[i] == TOF_FRAME_HEADER && buffer[i + 1] == TOF_FUNCTION_MARK) {
            return i;
        }
    }
    return -1;
}

int main(int argc, char **argv)
{
    int fd;
    struct tof_data data;
    int ret;

    if (argc < 2) {
        print_usage(argv[0]);
        return -1;
    }

    /* 打开设备 */
    fd = open(argv[1], O_RDWR);
    if (fd == -1) {
        printf("Failed to open %s: %s\n", argv[1], strerror(errno));
        return -1;
    }

    /* 帧解析缓冲区 */
    uint8_t buffer[1024];
    int buffer_pos = 0;
    uint8_t frame[TOF_FRAME_SIZE];
    int frame_complete = 0;

    do {
        /* 读取原始字节流 */
        ret = read(fd, buffer + buffer_pos, sizeof(buffer) - buffer_pos);

        if (ret > 0) {
            buffer_pos += ret;

            /* 帧解析模式：寻找并解析完整帧 */
            while (buffer_pos >= TOF_FRAME_SIZE) {
                int frame_start = find_frame_start(buffer, buffer_pos);

                if (frame_start >= 0) {
                    /* 找到帧头，检查是否有完整帧 */
                    if (frame_start + TOF_FRAME_SIZE <= buffer_pos) {
                        /* 复制完整帧 */
                        memcpy(frame, buffer + frame_start, TOF_FRAME_SIZE);

                        /* 显示原始帧数据（调试用） */
                        printf("Found frame at offset %d: ", frame_start);
                        show_raw_data(frame, TOF_FRAME_SIZE);

                        /* 解析帧 */
                        if (parse_tof_frame(frame, &data) == 0) {
                            printf("==========================================\n");
                            printf("TOF Module ID    : %d\n", data.module_id);
                            printf("System Time      : %u ms\n", data.system_time);
                            printf("Distance         : %u mm (%.3f m)\n", 
                                   data.distance_mm, data.distance_mm / 1000.0);
                            printf("Status           : %s (%d)\n", 
                                   data.status ? "Valid" : "Invalid", data.status);
                            printf("Signal Strength  : %u\n", data.signal_strength);
                            printf("Precision        : %u cm\n", data.precision);
                            printf("==========================================\n");
                            frame_complete = 1;
                        } else {
                            printf("Frame parsing failed\n");
                        }

                        /* 移除已处理的数据 */
                        int bytes_to_remove = frame_start + TOF_FRAME_SIZE;
                        memmove(buffer, buffer + bytes_to_remove, buffer_pos - bytes_to_remove);
                        buffer_pos -= bytes_to_remove;
                    } else {
                        /* 帧不完整，等待更多数据 */
                        break;
                    }
                } else {
                    /* 没找到帧头，丢弃一些数据 */
                    if (buffer_pos > TOF_FRAME_SIZE) {
                        memmove(buffer, buffer + 1, buffer_pos - 1);
                        buffer_pos--;
                    } else {
                        break;
                    }
                }
            }

            /* 缓冲区溢出保护 */
            if (buffer_pos > sizeof(buffer) - 100) {
                printf("Buffer overflow protection: resetting buffer\n");
                buffer_pos = 0;
            }

            /* 默认模式也循环显示，每次显示后等待一段时间 */
            if (frame_complete) {
                usleep(100000); /* 100ms间隔 */
                frame_complete = 0; /* 重置标志，继续读取下一帧 */
            }

        } else if (ret == 0) {
            printf("No data available\n");
            break;
        } else if (ret < 0) {
            if (errno == EINTR) {
                continue; /* 被信号中断，继续 */
            } else {
                printf("Read error: %s\n", strerror(errno));
                break;
            }
        }

    } while (1);

    close(fd);
    return 0;
}
