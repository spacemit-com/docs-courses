#include "stdio.h"
#include "unistd.h"
#include "sys/types.h"
#include "sys/stat.h"
#include "fcntl.h"
#include "stdlib.h"
#include "string.h"
#include <sys/ioctl.h>

/***************************************************************
文件名		: gy6500_test.c
描述	   	: GY6500(MPU6500)测试应用程序
***************************************************************/

/* 转换成实际的单位值 */
float accel_scale = 16.0f / 32768.0f;  /* ±16g量程下，最小单位为16g/32768 */
float gyro_scale = 2000.0f / 32768.0f; /* ±2000dps量程下，最小单位为2000dps/32768 */
float temp_scale = 1.0f / 340.0f;      /* 温度系数 */
float temp_offset = 36.53f;            /* 温度偏移量 */

/*
 * @description		: main主程序
 * @param - argc 	: argv数组元素个数
 * @param - argv 	: 具体参数
 * @return 			: 0 成功;其他 失败
 */
int main(int argc, char *argv[])
{
	int fd;
	char *filename;
	signed short databuf[7];
	unsigned char data[14];
	float accel_x, accel_y, accel_z;
	float gyro_x, gyro_y, gyro_z;
	float temp;
	int ret = 0;

	if (argc != 2) {
		printf("Error Usage!\r\n");
		return -1;
	}

	filename = argv[1];
	fd = open(filename, O_RDWR);
	if(fd < 0) {
		printf("can't open file %s\r\n", filename);
		return -1;
	}

	while (1) {
		ret = read(fd, databuf, sizeof(databuf));
		if(ret == 0) {
			/* 将原始数据转换为实际物理单位 */
			accel_x = databuf[0] * accel_scale;
			accel_y = databuf[1] * accel_scale;
			accel_z = databuf[2] * accel_scale;

			temp = (databuf[3] * temp_scale) + temp_offset;

			gyro_x = databuf[4] * gyro_scale;
			gyro_y = databuf[5] * gyro_scale;
			gyro_z = databuf[6] * gyro_scale;

			printf("加速度: X=%.2fg, Y=%.2fg, Z=%.2fg\r\n", accel_x, accel_y, accel_z);
			printf("陀螺仪: X=%.2f°/s, Y=%.2f°/s, Z=%.2f°/s\r\n", gyro_x, gyro_y, gyro_z);
			printf("温度: %.2f°C\r\n\n", temp);
		}
		usleep(500000); /* 延时500ms */
	}
	close(fd);	/* 关闭文件 */
	return 0;
}
