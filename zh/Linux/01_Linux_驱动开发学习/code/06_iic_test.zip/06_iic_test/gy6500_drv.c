#include <linux/types.h>
#include <linux/kernel.h>
#include <linux/delay.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/errno.h>
#include <linux/gpio.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/of_gpio.h>
#include <linux/semaphore.h>
#include <linux/timer.h>
#include <linux/i2c.h>
#include <linux/uaccess.h>
#include <linux/io.h>
#include "gy6500reg.h"
/***************************************************************
文件名		: gy6500_drv.c
描述	   	: GY6500(MPU6500)六轴传感器驱动程序
***************************************************************/
#define GY6500_CNT	1
#define GY6500_NAME	"gy6500"

struct gy6500_dev {
	dev_t devid;			 /* 设备号 	 */
	struct cdev cdev;		 /* cdev 	*/
	struct class *class;	 /* 类 		*/
	struct device *device;	 /* 设备 	 */
	struct device_node	*nd; /* 设备节点 */
	int major;			     /* 主设备号 */
	void *private_data;	     /* 私有数据 */
	short accel[3];          /* 加速度传感器值 (x,y,z) */
	short gyro[3];           /* 陀螺仪传感器值 (x,y,z) */
	short temp;              /* 温度传感器值 */
};

static struct gy6500_dev gy6500dev;

/*
 * @description	: 从gy6500读取多个寄存器数据
 * @param - dev:  gy6500设备
 * @param - reg:  要读取的寄存器首地址
 * @param - val:  读取到的数据
 * @param - len:  要读取的数据长度
 * @return 		: 操作结果
 */
static int gy6500_read_regs(struct gy6500_dev *dev, u8 reg, void *val, int len)
{
	int ret;
	struct i2c_msg msg[2];
	struct i2c_client *client = (struct i2c_client *)dev->private_data;

	/* msg[0]为发送要读取的首地址 */
	msg[0].addr = client->addr;			/* gy6500地址 */
	msg[0].flags = 0;					/* 标记为发送数据 */
	msg[0].buf = &reg;					/* 读取的首地址 */
	msg[0].len = 1;						/* reg长度*/

	/* msg[1]读取数据 */
	msg[1].addr = client->addr;			/* gy6500地址 */
	msg[1].flags = I2C_M_RD;			/* 标记为读取数据*/
	msg[1].buf = val;					/* 读取数据缓冲区 */
	msg[1].len = len;					/* 要读取的数据长度*/

	ret = i2c_transfer(client->adapter, msg, 2);
	if(ret == 2) {
		ret = 0;
	} else {
		printk("i2c rd failed=%d reg=%06x len=%d\n",ret, reg, len);
		ret = -EREMOTEIO;
	}
	return ret;
}

/*
 * @description	: 向gy6500多个寄存器写入数据
 * @param - dev:  gy6500设备
 * @param - reg:  要写入的寄存器首地址
 * @param - val:  要写入的数据缓冲区
 * @param - len:  要写入的数据长度
 * @return 	  :   操作结果
 */
static s32 gy6500_write_regs(struct gy6500_dev *dev, u8 reg, u8 *buf, u8 len)
{
	u8 b[256];
	struct i2c_msg msg;
	struct i2c_client *client = (struct i2c_client *)dev->private_data;

	b[0] = reg;					/* 寄存器首地址 */
	memcpy(&b[1],buf,len);		/* 将要写入的数据拷贝到数组b里面 */

	msg.addr = client->addr;	/* gy6500地址 */
	msg.flags = 0;				/* 标记为写数据 */

	msg.buf = b;				/* 要写入的数据缓冲区 */
	msg.len = len + 1;			/* 要写入的数据长度 */

	return i2c_transfer(client->adapter, &msg, 1);
}

/*
 * @description	: 读取gy6500指定寄存器值，读取一个寄存器
 * @param - dev:  gy6500设备
 * @param - reg:  要读取的寄存器
 * @return 	  :   读取到的寄存器值
 */
static unsigned char __maybe_unused gy6500_read_reg(struct gy6500_dev *dev, u8 reg)
{
	u8 data = 0;

	gy6500_read_regs(dev, reg, &data, 1);
	return data;
}

/*
 * @description	: 向gy6500指定寄存器写入指定的值，写一个寄存器
 * @param - dev:  gy6500设备
 * @param - reg:  要写的寄存器
 * @param - data: 要写入的值
 * @return   :    无
 */
static void gy6500_write_reg(struct gy6500_dev *dev, u8 reg, u8 data)
{
	u8 buf = 0;
	buf = data;
	gy6500_write_regs(dev, reg, &buf, 1);
}

/*
 * @description	: 读取GY6500的数据，读取原始数据，包括加速度、陀螺仪和温度
 * @param - accel: 加速度数据
 * @param - gyro : 陀螺仪数据
 * @param - temp : 温度数据
 * @return 		: 无
 */
void gy6500_readdata(struct gy6500_dev *dev)
{
	unsigned char buf[14];

	/* 读取加速度、温度和陀螺仪数据，一共14个字节 */
	gy6500_read_regs(dev, MPU_ACCEL_XOUTH_REG, buf, 14);

	/* 加速度 */
	dev->accel[0] = ((u16)buf[0] << 8) | buf[1];  /* X轴 */
	dev->accel[1] = ((u16)buf[2] << 8) | buf[3];  /* Y轴 */
	dev->accel[2] = ((u16)buf[4] << 8) | buf[5];  /* Z轴 */

	/* 温度 */
	dev->temp = ((u16)buf[6] << 8) | buf[7];

	/* 陀螺仪 */
	dev->gyro[0] = ((u16)buf[8] << 8) | buf[9];   /* X轴 */
	dev->gyro[1] = ((u16)buf[10] << 8) | buf[11]; /* Y轴 */
	dev->gyro[2] = ((u16)buf[12] << 8) | buf[13]; /* Z轴 */
}

/*
 * @description		: 打开设备
 * @param - inode 	: 传递给驱动的inode
 * @param - filp 	: 设备文件，file结构体有个叫做private_data的成员变量
 * 					  一般在open的时候将private_data指向设备结构体。
 * @return 			: 0 成功;其他 失败
 */
static int gy6500_open(struct inode *inode, struct file *filp)
{
	filp->private_data = &gy6500dev;

	/* 初始化GY6500 */
	gy6500_write_reg(&gy6500dev, MPU_PWR_MGMT1_REG, 0x80);	/* 复位GY6500 */
	mdelay(100);                                     /* 等待复位完成 */
	gy6500_write_reg(&gy6500dev, MPU_PWR_MGMT1_REG, 0x00);	/* 唤醒GY6500 */

	/* 设置陀螺仪和加速度范围 */
	gy6500_write_reg(&gy6500dev, MPU_GYRO_CFG_REG, 0x18);   /* 陀螺仪量程：±2000dps */
	gy6500_write_reg(&gy6500dev, MPU_ACCEL_CFG_REG, 0x18);  /* 加速度量程：±16g */

	/* 设置采样率 */
	gy6500_write_reg(&gy6500dev, MPU_SAMPLE_RATE_REG, 0x07); /* 采样率：1000/(1+7)=125Hz */

	/* 配置低通滤波器 */
	gy6500_write_reg(&gy6500dev, MPU_CFG_REG, 0x06);         /* 低通滤波器：5Hz */

	return 0;
}

/*
 * @description		: 从设备读取数据
 * @param - filp 	: 要打开的设备文件(文件描述符)
 * @param - buf 	: 返回给用户空间的数据缓冲区
 * @param - cnt 	: 要读取的数据长度
 * @param - offt 	: 相对于文件首地址的偏移
 * @return 			: 读取的字节数，如果为负值，表示读取失败
 */
static ssize_t gy6500_read(struct file *filp, char __user *buf, size_t cnt, loff_t *off)
{
	short data[7];
	long err = 0;

	struct gy6500_dev *dev = (struct gy6500_dev *)filp->private_data;

	gy6500_readdata(dev);

	data[0] = dev->accel[0];  /* X轴加速度 */
	data[1] = dev->accel[1];  /* Y轴加速度 */
	data[2] = dev->accel[2];  /* Z轴加速度 */
	data[3] = dev->temp;      /* 温度 */
	data[4] = dev->gyro[0];   /* X轴陀螺仪 */
	data[5] = dev->gyro[1];   /* Y轴陀螺仪 */
	data[6] = dev->gyro[2];   /* Z轴陀螺仪 */

	err = copy_to_user(buf, data, sizeof(data));
	return 0;
}

/*
 * @description		: 关闭/释放设备
 * @param - filp 	: 要关闭的设备文件(文件描述符)
 * @return 			: 0 成功;其他 失败
 */
static int gy6500_release(struct inode *inode, struct file *filp)
{
	return 0;
}

/* GY6500操作函数 */
static const struct file_operations gy6500_ops = {
	.owner = THIS_MODULE,
	.open = gy6500_open,
	.read = gy6500_read,
	.release = gy6500_release,
};

/*
 * @description     : i2c驱动的probe函数，当驱动与
 *                    设备匹配以后此函数就会执行
 * @param - client  : i2c设备
 * @return          : 0，成功;其他负值,失败
 */
static int gy6500_probe(struct i2c_client *client)
{
	/* 1、构建设备号 */
	if (gy6500dev.major) {
		gy6500dev.devid = MKDEV(gy6500dev.major, 0);
		register_chrdev_region(gy6500dev.devid, GY6500_CNT, GY6500_NAME);
	} else {
		alloc_chrdev_region(&gy6500dev.devid, 0, GY6500_CNT, GY6500_NAME);
		gy6500dev.major = MAJOR(gy6500dev.devid);
	}

	/* 2、注册设备 */
	cdev_init(&gy6500dev.cdev, &gy6500_ops);
	cdev_add(&gy6500dev.cdev, gy6500dev.devid, GY6500_CNT);

	/* 3、创建类 */
	gy6500dev.class = class_create(GY6500_NAME);
	if (IS_ERR(gy6500dev.class)) {
		return PTR_ERR(gy6500dev.class);
	}

	/* 4、创建设备 */
	gy6500dev.device = device_create(gy6500dev.class, NULL, gy6500dev.devid, NULL, GY6500_NAME);
	if (IS_ERR(gy6500dev.device)) {
		return PTR_ERR(gy6500dev.device);
	}

	gy6500dev.private_data = client;

	return 0;
}

/*
 * @description     : i2c驱动的remove函数，移除i2c驱动的时候此函数会执行
 * @param - client 	: i2c设备
 * @return          : 无
 */
static void gy6500_remove(struct i2c_client *client)
{
	/* 删除设备 */
	cdev_del(&gy6500dev.cdev);
	unregister_chrdev_region(gy6500dev.devid, GY6500_CNT);

	/* 注销掉类和设备 */
	device_destroy(gy6500dev.class, gy6500dev.devid);
	class_destroy(gy6500dev.class);
}

/* 传统匹配方式ID列表 */
static const struct i2c_device_id gy6500_id[] = {
	{"bianbusense,gy6500", 0},
	{}
};

/* 设备树匹配列表 */
static const struct of_device_id gy6500_of_match[] = {
	{ .compatible = "bianbusense,gy6500" },
	{ /* Sentinel */ }
};

/* i2c驱动结构体 */
static struct i2c_driver gy6500_driver = {
	.probe = gy6500_probe,
	.remove = gy6500_remove,
	.driver = {
			.owner = THIS_MODULE,
		   	.name = "gy6500",
		   	.of_match_table = gy6500_of_match,
		   },
	.id_table = gy6500_id,
};

/*
 * @description	: 驱动入口函数
 * @param 		: 无
 * @return 		: 无
 */
static int __init gy6500_init(void)
{
	int ret = 0;

	ret = i2c_add_driver(&gy6500_driver);
	return ret;
}

/*
 * @description	: 驱动出口函数
 * @param 		: 无
 * @return 		: 无
 */
static void __exit gy6500_exit(void)
{
	i2c_del_driver(&gy6500_driver);
}

module_init(gy6500_init);
module_exit(gy6500_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Modified from zuozhongkai's code");
