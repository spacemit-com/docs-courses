#include <linux/module.h>
#include <linux/platform_device.h>

#include <linux/fs.h>
#include <linux/errno.h>
#include <linux/miscdevice.h>
#include <linux/kernel.h>
#include <linux/major.h>
#include <linux/mutex.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/stat.h>
#include <linux/init.h>
#include <linux/device.h>
#include <linux/tty.h>
#include <linux/kmod.h>
#include <linux/gfp.h>
#include <linux/gpio/consumer.h>
#include <linux/of.h>
#include <linux/input.h>
#include <linux/interrupt.h>
#include <linux/of_irq.h>
#include <linux/timer.h>


// 全局变量：GPIO描述符、input子系统设备、IRQ号
static struct gpio_desc *input_gpio; // 用于保存获取到的GPIO
static struct input_dev *test_input_dev; // input子系统设备结构体
// static int irq_num; // 中断号


#define POLL_INTERVAL (HZ/20) // 50ms 轮询一次
static struct timer_list poll_timer;
static int last_key_state = 0;

// 定时器回调函数，定期读取GPIO并上报input事件
static void poll_gpio_func(struct timer_list *t)
{
    int value = gpiod_get_value(input_gpio);
     if (value != last_key_state) {
        input_report_key(test_input_dev, KEY_0, value);
        input_sync(test_input_dev);
        last_key_state = value;
    }
    mod_timer(&poll_timer, jiffies + POLL_INTERVAL);
}


// probe函数：驱动与设备匹配时调用
static int chip_demo_gpio_probe(struct platform_device *pdev)
{
    int err;

    // 获取设备树中分配的GPIO（label为NULL，获取gpios第一个，即72号）
    input_gpio = gpiod_get(&pdev->dev, NULL, GPIOD_IN);
    if (IS_ERR(input_gpio)) {
        dev_err(&pdev->dev, "Failed to get GPIO for test\n");
        return PTR_ERR(input_gpio);
    }

    // 分配input_dev结构体
    test_input_dev = devm_input_allocate_device(&pdev->dev);
    if (!test_input_dev) {
        gpiod_put(input_gpio);
        return -ENOMEM;
    }

    // 填充input_dev信息
    test_input_dev->name = "bianbu_input";
    test_input_dev->phys = "bianbu/gpio72";
    test_input_dev->id.bustype = BUS_HOST;

    // 设置支持的事件类型和按键类型
    __set_bit(EV_KEY, test_input_dev->evbit);
    __set_bit(KEY_0, test_input_dev->keybit); // 只支持KEY_0

    // 注册input设备
    err = input_register_device(test_input_dev);
    if (err) {
        gpiod_put(input_gpio);
        return err;
    }

    // 初始化定时器，定期轮询GPIO
    timer_setup(&poll_timer, poll_gpio_func, 0);
    last_key_state = gpiod_get_value(input_gpio);
    mod_timer(&poll_timer, jiffies + POLL_INTERVAL);

    dev_info(&pdev->dev, "input子系统驱动已加载(GPIO轮询)\n");
    return 0;
}


// remove函数：驱动卸载时调用
static int chip_demo_gpio_remove(struct platform_device *pdev)
{
    del_timer_sync(&poll_timer); // 删除定时器
    input_unregister_device(test_input_dev); // 注销input设备
    gpiod_put(input_gpio); // 释放GPIO
    return 0;
}


// 设备树匹配表
static const struct of_device_id bianbu_input[] = {
    { .compatible = "bianbu,input-test" },
    { },
};


/* 1. 定义platform_driver */
static struct platform_driver chip_demo_gpio_driver = {
    .probe      = chip_demo_gpio_probe,
    .remove     = chip_demo_gpio_remove,
    .driver     = {
        .name   = "bianbu_input_test",
        .of_match_table = bianbu_input,
    },
};

// 注册platform_driver
module_platform_driver(chip_demo_gpio_driver);

MODULE_LICENSE("GPL"); // 开源协议声明


