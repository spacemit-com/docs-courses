# Linux Input子系统驱动测试项目

## 项目简介

这是一个Linux内核Input子系统驱动测试项目，实现了一个基于GPIO轮询的输入设备驱动程序及其对应的用户空间测试程序。该项目演示了如何在Linux内核中编写一个platform驱动程序来创建input设备，并通过GPIO轮询方式检测按键状态。

## 文件说明

### 1. inputdrv.c - Input子系统内核驱动模块

这是项目的核心文件，包含了完整的Linux内核Input子系统驱动程序代码。

**主要功能：**
- 实现了一个基于platform_driver的Input设备驱动程序
- 通过设备树获取GPIO资源
- 创建Input子系统设备，注册为按键输入设备
- 使用定时器定期轮询GPIO状态变化

**关键特性：**
- **设备树兼容性：** 支持`compatible = "bianbu,input-test"`的设备树节点
- **GPIO轮询检测：** 通过定时器每50ms轮询GPIO状态，检测按键变化
- **Input子系统集成：** 使用标准的Linux Input子系统框架
- **按键事件上报：** 检测到GPIO状态变化时自动上报KEY_0按键事件

**驱动工作流程：**
1. 模块加载时注册platform_driver
2. 设备树匹配成功后调用probe函数
3. 从设备树获取GPIO资源并配置为输入模式
4. 分配并初始化input_dev结构体
5. 注册input设备到内核Input子系统
6. 启动定时器定期轮询GPIO状态
7. 检测到状态变化时通过input_report_key上报按键事件

**技术细节：**
- **轮询间隔：** 50ms (HZ/20)
- **支持按键：** KEY_0
- **事件类型：** EV_KEY
- **GPIO配置：** GPIOD_IN (输入模式)

### 2. inputtest.c - 用户空间测试程序

这是一个C语言用户空间应用程序，用于监听和显示Input设备的按键事件。

**主要功能：**
- 打开指定的input事件设备文件
- 实时监听input事件并解析显示
- 专门处理按键事件(EV_KEY)类型

**使用方法：**
```bash
# 监听input事件设备
./inputtest /dev/input/eventX

# 例如：
./inputtest /dev/input/event0
```

**程序逻辑：**
1. 检查命令行参数（input设备文件路径）
2. 以只读模式打开指定的input事件设备文件
3. 循环读取input_event结构体数据
4. 解析并显示按键事件的时间戳、类型、键码和状态
5. 按键按下时value=1，松开时value=0


### 3. Makefile - 编译配置文件

这是项目的编译配置文件，支持同时编译内核模块和用户空间程序。

**编译目标：**
- **内核模块编译：** 将`inputdrv.c`编译成`inputdrv.ko`内核模块
- **用户程序编译：** 将`inputtest.c`编译成可执行文件`inputtest`

**重要配置说明：**
- `KERN_DIR`: 指定Linux内核源码路径
- `CROSS_COMPILE`: 交叉编译工具链前缀
- `obj-m += inputdrv.o`: 指定要编译的内核模块
