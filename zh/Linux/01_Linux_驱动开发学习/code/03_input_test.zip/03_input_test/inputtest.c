#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <linux/input.h>
#include <stdlib.h>
#include <errno.h>
#include <time.h>

/*
 * ./gpiotest /dev/input/eventX
 * 监听 input 事件并打印
 */
int main(int argc, char **argv)
{
    int fd;
    struct input_event ev;
    ssize_t n;

    if (argc != 2) {
        printf("Usage: %s <input_dev>\n", argv[0]);
        return -1;
    }

    fd = open(argv[1], O_RDONLY);
    if (fd == -1) {
        printf("can not open file %s\n", argv[1]);
        return -1;
    }

    printf("Listening for input events on %s...\n", argv[1]);
    while (1) {
        n = read(fd, &ev, sizeof(ev));
        if (n == sizeof(ev)) {
            if (ev.type == EV_KEY) {
                printf("time %ld.%06ld\tEV_KEY\tcode %d\tvalue %d\n",
                    ev.time.tv_sec, ev.time.tv_usec, ev.code, ev.value);
            }
        } else if (n < 0 && errno != EINTR) {
            perror("read");
            break;
        }
    }
    close(fd);
    return 0;
}


